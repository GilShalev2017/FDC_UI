import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TasksCardViewComponent } from './tasks-card-view.component';

describe('TasksCardViewComponent', () => {
  let component: TasksCardViewComponent;
  let fixture: ComponentFixture<TasksCardViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TasksCardViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TasksCardViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
