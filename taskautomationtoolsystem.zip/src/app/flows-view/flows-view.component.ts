import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { FlowsService } from "../services/flows.service";
import { OperationsService } from "../services/operations.service";
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { ODTask } from "../models/ODTask";
import { ODFlow } from "../models/ODFlow";
import { DataSource } from '@angular/cdk/collections';
import { AddFlowComponent } from "../add-flow/add-flow.component";
import { EditFlowComponent } from '../edit-flow/edit-flow.component';
import { DeleteFlowComponent } from '../delete-flow/delete-flow.component';
import { BehaviorSubject, fromEvent, merge, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { AuthService } from './../auth/auth.service';

@Component({
  selector: 'app-flows-view',
  templateUrl: './flows-view.component.html',
  styleUrls: ['./flows-view.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class FlowsViewComponent implements OnInit {

  displayedColumns = ['Name', 'Description', 'Tasks', 'CreatedBy', 'CreatedAt', 'actions'];
  exampleDatabase: FlowsService | null;
  dataSource: FlowsDataSource | null;
  index: number;
  id: string;
  expandedElement: ODFlow | null;
 
  constructor(public httpClient: HttpClient,
              public dialog: MatDialog,
              public flowsService: FlowsService,
              private authService: AuthService,
              public operationsService: OperationsService) {}

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild('filter',  {static: true}) filter: ElementRef;

  ngOnInit() {
    this.loadData();
  }
  
  refresh() {
    this.loadData();
  }

  addNew() {
    let odFlow: ODFlow = {};
    const dialogRef = this.dialog.open(AddFlowComponent, {
      data: {oDFlow: ODFlow }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        // After dialog is closed we're doing frontend updates
        // For add we're just pushing a new row inside DataService
        this.exampleDatabase.dataChange.value.push(this.flowsService.getDialogData()); 
        this.refreshTable();
      }
    });
  }

  startEdit(i: number, row: ODFlow) {
  
    const dialogRef = this.dialog.open(EditFlowComponent, {
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        // When using an edit things are little different, firstly we find record inside DataService by id
        const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.Id === row.Id);
        // Then you update that record using data from dialogData (values you enetered)
        this.exampleDatabase.dataChange.value[foundIndex] = this.flowsService.getDialogData();
        // And lastly refresh table
        this.refreshTable();
      }
    });
  }

  deleteItem(i: number, row: ODFlow) {
   
    const dialogRef = this.dialog.open(DeleteFlowComponent, {
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.Id === row.Id);
        // for delete we use splice in order to remove single object from DataService
        this.exampleDatabase.dataChange.value.splice(foundIndex, 1);
        this.refreshTable();
      }
    });
  }
 
  private refreshTable() {
    // https://github.com/marinantonio/angular-mat-table-crud/issues/12
    this.paginator._changePageSize(this.paginator.pageSize);
  }

  public loadData() {
    this.exampleDatabase = new FlowsService(this.httpClient, this.authService, this.operationsService);
    
    this.dataSource = new FlowsDataSource(this.exampleDatabase, this.paginator, this.sort);
    
    fromEvent(this.filter.nativeElement, 'keyup')
      // .debounceTime(150)
      // .distinctUntilChanged()
      .subscribe(() => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter.nativeElement.value;
      });
  }
}

export class FlowsDataSource extends DataSource<ODFlow> {
  _filterChange = new BehaviorSubject('');

  get filter(): string {
    return this._filterChange.value;
  }

  set filter(filter: string) {
    this._filterChange.next(filter);
  }

  filteredData: ODFlow[] = [];
  renderedData: ODFlow[] = [];

  constructor(public _exampleDatabase: FlowsService,
              public _paginator: MatPaginator,
              public _sort: MatSort) {
    super();
    // Reset to the first page when the user changes the filter.
    this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
  }

  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<ODFlow[]> {
    // Listen for any changes in the base data, sorting, filtering, or pagination
    const displayDataChanges = [
      this._exampleDatabase.dataChange,
      this._sort.sortChange,
      this._filterChange,
      this._paginator.page
    ];

    this._exampleDatabase.getAllFlows();


    return merge(...displayDataChanges).pipe(map( () => {
        // Filter data
        this.filteredData = this._exampleDatabase.data.slice().filter((odf: ODFlow) => {
          const searchStr = (odf.Id + odf.Name + odf.Description).toLowerCase();
          return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
        });

        // Sort filtered data
        const sortedData = this.sortData(this.filteredData.slice());

        // Grab the page's slice of the filtered sorted data.
        const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
        this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
        return this.renderedData;
      }
    ));
  }

  disconnect() {}


  /** Returns a sorted copy of the database data. */
  sortData(data: ODFlow[]): ODFlow[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      let propertyA: number | string = '';
      let propertyB: number | string = '';

      switch (this._sort.active) {
        // case 'Id': [propertyA, propertyB] = [a.Id, b.Id]; break;
        case 'Name': [propertyA, propertyB] = [a.Name, b.Name]; break;
        case 'Description': [propertyA, propertyB] = [a.Description, b.Description]; break;
        // case 'CategoryGroup': [propertyA, propertyB] = [a.CategoryGroup, b.CategoryGroup]; break;
        // case 'ProgramType': [propertyA, propertyB] = [a.ProgramType, b.ProgramType]; break;
      }

      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

      return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1);
    });
  }
}
