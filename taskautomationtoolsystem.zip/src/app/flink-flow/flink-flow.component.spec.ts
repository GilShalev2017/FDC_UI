import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlinkFlowComponent } from './flink-flow.component';

describe('FlinkFlowComponent', () => {
  let component: FlinkFlowComponent;
  let fixture: ComponentFixture<FlinkFlowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlinkFlowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlinkFlowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
