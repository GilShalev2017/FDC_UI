import { Component, OnInit, OnDestroy } from '@angular/core';
import { OperationsService } from "../services/operations.service";
import { FlinkJar } from "../models/FlinkJar";
import { FlinkTaskPayload, FlinkTaskType } from "../models/FlinkTaskPayload";
import { ProgramsService } from "../services/programs.service";

@Component({
  selector: 'app-flink-flow',
  templateUrl: './flink-flow.component.html',
  styleUrls: ['./flink-flow.component.css']
})
export class FlinkFlowComponent implements OnInit, OnDestroy {

  selectedJar: string;
  selectedDeployedJar: string;
  _file;
  _jarFilenName: string;
  _isUploading:boolean = false;
  _presignedUrl:string;
  _s3JarUploaded:boolean = false;
  _intervalId: number;
  _stepperStage: number;

  displayedColumns: string[] = ['jid', 'name', 'startTime', 'duration', 'endTime', 'tasks', 'state', 'actions' ];

  constructor( public operationsService: OperationsService,
               public programsService: ProgramsService) {
  }

  ngOnDestroy() {
    
    window.clearInterval(this._intervalId);
  }

  ngOnInit() {

    this.getAvailableFlinkJars();
    this.getDeployedFlinkJars();

    // this.operationsService.deploymentSelectionChanged.subscribe( value => {
    //     if (value === true) {
    //       console.log("!"); 
          
    //       this.operationsService.deploymentSelectionChanged.next(false);

    //        window.clearInterval(this._intervalId);

    //        if(this._stepperStage == 2) {

    //           this.getDeployedFlinkJars();
    //           this.operationsService.flinkJobs = [];
    //           // this._intervalId = window.setInterval( () => 
    //           //   {
    //           //     this.getJobsOverview()
    //           //   }, 2000);
    //        }
    //     }
    // });
  }

   getAvailableFlinkJars() {
    this.operationsService.getFlinkJars()
       .subscribe( (arrivedData: string[]) => {
      });
  }

  uploadJarToFlinkCluster() {

    this.operationsService._isUploadedToFlink = false;
    this.operationsService._isUploadingToFlink = true;

    let flinkTaskPayload: FlinkTaskPayload = {
        FlinkTaskType: FlinkTaskType.UploadJar,
        JarName: this.selectedJar,
        DeploymentId: this.operationsService.selectedDeploymentId
    }

    this.operationsService.startFlinkTask(flinkTaskPayload);
  }

  getDeployedFlinkJars() {
    
    let flinkTaskPayload: FlinkTaskPayload = {
        FlinkTaskType: FlinkTaskType.GetDeployedJarList,
        DeploymentId: this.operationsService.selectedDeploymentId
    }

    this.operationsService.startFlinkTask(flinkTaskPayload);
      // .subscribe( (arrivedData: FlinkJar[]) => {
      // });
  }

  runFlinkJar() {
    let flinkTaskPayload: FlinkTaskPayload = {
            FlinkTaskType: FlinkTaskType.RunJar,
            JarName: this.selectedDeployedJar,
            DeploymentId: this.operationsService.selectedDeploymentId
        }

    this.operationsService.startFlinkTask(flinkTaskPayload);
  }

  getFiles(event) {
    this._file = event.target.files[0];
    this._jarFilenName = event.target.files[0].name;
    this._isUploading = false;
    this._s3JarUploaded = false;   
  }

  uploadJarToS3()
  {
    this._isUploading = true;
    this._s3JarUploaded = false;   
    // Get Presigned url
    this.programsService.getProgramPresignedUrl(this._jarFilenName, "", "Flink/FlinkJars")
      .subscribe( (url: string) => {
        this._presignedUrl = url;

        //  Upload to uploadFileToS3
        if(this.programsService.uploadFileToS3(this._presignedUrl, this._file) == true)
        {
           this._isUploading = false;
           this._s3JarUploaded = true;
           this.getAvailableFlinkJars();
        }
      });
  }

  public onStepChange(event: any): void {
    console.log(event.selectedIndex);

    this._stepperStage = event.selectedIndex;

    if(event.selectedIndex == 2) {
      this._intervalId = window.setInterval( () => 
      {
        this.getJobsOverview()
       }, 2000);
    }
    else {
      window.clearInterval(this._intervalId);
    }
  }

   getJobsOverview(): void {
    let flinkTaskPayload: FlinkTaskPayload = {
            FlinkTaskType: FlinkTaskType.JobsOverview,
            DeploymentId: this.operationsService.selectedDeploymentId
          }

    this.operationsService.startFlinkTask(flinkTaskPayload);
  }

}
