import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BootstrapLayoutComponent } from './bootstrap-layout.component';

describe('BootstrapLayoutComponent', () => {
  let component: BootstrapLayoutComponent;
  let fixture: ComponentFixture<BootstrapLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BootstrapLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BootstrapLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
