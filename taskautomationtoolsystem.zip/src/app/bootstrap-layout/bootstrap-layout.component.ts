import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bootstrap-layout',
  templateUrl: './bootstrap-layout.component.html',
  styleUrls: ['./bootstrap-layout.component.css']
})
export class BootstrapLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
