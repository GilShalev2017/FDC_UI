import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationsTreeComponent } from './configurations-tree.component';

describe('ConfigurationsTreeComponent', () => {
  let component: ConfigurationsTreeComponent;
  let fixture: ComponentFixture<ConfigurationsTreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigurationsTreeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationsTreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
