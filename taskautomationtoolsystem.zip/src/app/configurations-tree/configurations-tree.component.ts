import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { OperationsService } from "../services/operations.service";
import { of as observableOf } from 'rxjs';
import { AuthService } from './../auth/auth.service';

/** File node data with nested structure. */
export interface FileNode {
  name: string;
  fileType: string;
  children?: FileNode[];
  parent?: string;
}

/** Flat node with expandable and level information */
export interface TreeNode {
  name: string;
  fileType: string;
  level: number;
  expandable: boolean;
  parent?: string;
}

@Component({
  selector: 'app-configurations-tree',
  templateUrl: './configurations-tree.component.html',
  styleUrls: ['./configurations-tree.component.css']
})
export class ConfigurationsTreeComponent implements OnInit {

  @Output() configFileSelected: EventEmitter<string> = new EventEmitter();

  /** The TreeControl controls the expand/collapse state of tree nodes.  */
  treeControl: FlatTreeControl<TreeNode>;

  /** The TreeFlattener is used to generate the flat list of items from hierarchical data. */
  treeFlattener: MatTreeFlattener<FileNode, TreeNode>;

  /** The MatTreeFlatDataSource connects the control and flattener to provide data. */
  dataSource: MatTreeFlatDataSource<FileNode, TreeNode>;

  constructor(public operationsService: OperationsService) {
    this.treeFlattener = new MatTreeFlattener(this.transformer, this.getLevel, this.isExpandable, this.getChildren);
    this.treeControl = new FlatTreeControl<TreeNode>(this.getLevel, this.isExpandable);
    this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
    
  }

 /** Transform the data to something the tree can read. */
  transformer(node: FileNode, level: number) {
    return {
      name: node.name,
      fileType: node.fileType,
      level: level,
      expandable: !!node.children,
      parent: node.parent
    };
  }

 /** Get the level of the node */
  getLevel(node: TreeNode) {
    return node.level;
  }

  /** Return whether the node is expanded or not. */
  isExpandable(node: TreeNode) {
    return node.expandable;
  };

  /** Get the children for the node. */
  getChildren(node: FileNode) {
    return observableOf(node.children);
  }

  /** Get whether the node has children or not. */
  hasChild(index: number, node: TreeNode){
    return node.expandable;
  }


  ngOnInit() {
  
    this.operationsService.getConfigurations()
     
      .subscribe( (results: FileNode[]) => {

         //this.dataSource.data = results;
         
         let resultsWithParent = this.setFileNodeParent(results);

         this.dataSource.data = resultsWithParent;
         //this.treeControl.expandAll();

      });
  }

  selectFile(selectedFile: any) {
    //TODO temporarily this is good only for one level
    let keyName = selectedFile.parent + "/" + selectedFile.name;

    this.configFileSelected.emit(keyName);
  }

  setFileNodeParent(results: FileNode[]): FileNode[]{
 
    results.forEach(element => {
      
      if(element.fileType === 'folder')
      {
        if(element.children != null) {
        
          element.children.forEach(elementChild => {
          
            elementChild.parent = element.name;
          });
        }
      }
    });

    return results;
  }
}
