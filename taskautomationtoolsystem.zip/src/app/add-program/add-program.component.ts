import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ProgramsService } from "../services/programs.service";
import { FormControl, Validators } from '@angular/forms';
import { ODProgram } from "../models/ODProgram";

@Component({
  selector: 'app-add-program',
  templateUrl: './add-program.component.html',
  styleUrls: ['./add-program.component.css']
})
export class AddProgramComponent {

  // prerequisites = new FormControl();
  // prerequisiteList: string[] = ['AwsCredentials', 'AwsCli', 'Kubectl', 'Java', 'DotNet', 'Zip', 'None'];

  _presignedUrl:string;
  _file;
  _isUploading:boolean = false;

  constructor(public dialogRef: MatDialogRef<AddProgramComponent>,
              @Inject(MAT_DIALOG_DATA) public data: ODProgram,
              public programService: ProgramsService) { }


  formControl = new FormControl('', [
    Validators.required
    // Validators.email,
  ]);

   getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }
  
  submit() {
  
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  public confirmAdd(): void {

    this._isUploading = true;

    // Get Presigned url
    this.programService.getProgramPresignedUrl(this.data.Name, this.data.Package, this.data.CategoryGroup.toString())
      .subscribe( (url: string) => {
        this._presignedUrl = url;

        //  Upload to uploadFileToS3
        if(this.programService.uploadFileToS3(this._presignedUrl, this._file) == true)
        {
            //  Add to DynamoDB
            this.programService.addProgramToDynamoDB(this.data).subscribe(
              (data: ODProgram) => {
                this.programService.addProgram(this.data);
                
                this._isUploading = false;
                this.dialogRef.close(1);
          });  
        }
      });
  }

  getFiles(event) {
    this._file = event.target.files[0];
    this.data.Package = event.target.files[0].name;
  }

  fixNameString(name: string) {
    this.data.Name = name.replace(/\s+/g, '_');
  }
}
