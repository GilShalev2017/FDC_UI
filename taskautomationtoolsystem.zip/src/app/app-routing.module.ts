import { NgModule } from '@angular/core';
import { Routes, RouterModule, CanActivate } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { BootstrapLayoutComponent } from "./bootstrap-layout/bootstrap-layout.component";
import { MyBootstrapLayoutComponent } from "./my-bootstrap-layout/my-bootstrap-layout.component";
import { DocumentComponent } from "./document/document.component";
import { TaskViewComponent } from "./task-view/task-view.component";
import { TasksViewComponent } from "./tasks-view/tasks-view.component";
import { MaterialTaskViewComponent } from './material-task-view/material-task-view.component';
import { ProgramViewComponent } from './program-view/program-view.component';
import { TaskReportComponent } from './task-report/task-report.component';
import { TopologyViewComponent } from './topology-view/topology-view.component';
import { FlowViewComponent } from './flow-view/flow-view.component';
import { FlowsViewComponent } from './flows-view/flows-view.component';
import { FlinkFlowComponent } from './flink-flow/flink-flow.component';
import { FlinkRunningJobsComponent } from './flink-running-jobs/flink-running-jobs.component';
import { ConfigurationsComponent } from './configurations/configurations.component';

import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { AuthGuard } from './auth/auth.guard';
import { LoginFormComponent } from './login-form/login-form.component';

const routes: Routes = [
  { path: '', redirectTo: 'flow-view', pathMatch: 'full'},
  
  //{ path: 'about', component: AboutComponent, canActivate: [AuthGuard] },
  // { path: 'bootstrap-layout', component: BootstrapLayoutComponent },
  // { path: 'my-bootstrap-layout', component: MyBootstrapLayoutComponent },
  // { path: 'document', component: DocumentComponent },
  { path: 'material-task-view', component: MaterialTaskViewComponent },
  { path: 'task-report', component: TaskReportComponent },
  { path: 'configurations', component: ConfigurationsComponent, canActivate: [AuthGuard] },
  { path: 'task-view', component: TaskViewComponent, canActivate: [AuthGuard] },
  { path: 'tasks-view', component: TasksViewComponent, canActivate: [AuthGuard] },
  { path: 'program-view', component: ProgramViewComponent, canActivate: [AuthGuard] },
  { path: 'topology-view', component: TopologyViewComponent, canActivate: [AuthGuard] },
  { path: 'flows-view', component: FlowsViewComponent, canActivate: [AuthGuard] },
  { path: 'flow-view', component: FlowViewComponent, canActivate: [AuthGuard] },
  
  { path: 'flink-running-jobs', component: FlinkRunningJobsComponent, canActivate: [AuthGuard] },

  { path: 'flink-flow', component: FlinkFlowComponent, canActivate: [AuthGuard] },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'login-form', component: LoginFormComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
