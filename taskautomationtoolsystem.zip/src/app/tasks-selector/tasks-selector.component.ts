import {Component, OnInit, Injectable, Input} from '@angular/core';
import {FlatTreeControl} from '@angular/cdk/tree';
import {MatTreeFlatDataSource, MatTreeFlattener} from'@angular/material/tree';
import {SelectionModel} from '@angular/cdk/collections';
import {OperationsService} from "../services/operations.service";
import {ProgramsService} from "../services/programs.service";
import {Subscription} from "rxjs";
import {ODTask} from "../models/ODTask";
import {ODProgram} from "../models/ODProgram";
import {CategoryGroup} from '../models/ODProgram';
import {BehaviorSubject, Observable, of as observableOf} from 'rxjs';
import {CdkDragDrop, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';

/**
 * Node for to-do item
 */
export class TodoItemNode {
  item: string;
  ODTask?: ODTask;
  children?: TodoItemNode[];
}

/** Flat to-do item node with expandable and level information */
export class TodoItemFlatNode {
  item: string;
  ODTask?: ODTask;
  level: number;
  expandable: boolean;
}

/**
 * The Json object for to-do list data.
 */
 const TREE_DATA = {
 };

 /**
 * Checklist database, it can build a tree structured Json object.
 * Each node in Json object represents a to-do item or a category.
 * If a node is a category, it has children items and new items can be added under the category.
 */
@Injectable()
export class ChecklistDatabase {
  dataChange = new BehaviorSubject<TodoItemNode[]>([]);

  get data(): TodoItemNode[] { return this.dataChange.value; }

  constructor() {
    this.initialize();
  }

  initialize() {
    // Build the tree nodes from Json object. The result is a list of `TodoItemNode` with nested
    //     file node as children.
    const data = this.buildFileTree(TREE_DATA, 0);

    // Notify the change.
    this.dataChange.next(data);
  }

  /**
   * Build the file structure tree. The `value` is the Json object, or a sub-tree of a Json object.
   * The return value is the list of `TodoItemNode`.
   */
  buildFileTree(obj: object, level: number): TodoItemNode[] {
    return Object.keys(obj).reduce<TodoItemNode[]>((accumulator, key) => {
      const value = obj[key];
      const node = new TodoItemNode();
      node.item = key;

      if (value != null) {
        if (typeof value === 'object') {
          node.children = this.buildFileTree(value, level + 1);
        } else {
          node.item = value;
        }
      }

      return accumulator.concat(node);
    }, []);
  }
}

@Component({
  selector: 'app-tasks-selector',
  templateUrl: './tasks-selector.component.html',
  styleUrls: ['./tasks-selector.component.css'],
  providers: [ChecklistDatabase]
})
export class TasksSelectorComponent implements OnInit {

/** Map from flat node to nested node. This helps us finding the nested node to be modified */
  flatNodeMap = new Map<TodoItemFlatNode, TodoItemNode>();

  /** Map from nested node to flattened node. This helps us to keep the same object for selection */
  nestedNodeMap = new Map<TodoItemNode, TodoItemFlatNode>();

  /** A selected parent node to be inserted */
  selectedParent: TodoItemFlatNode | null = null;

  treeControl: FlatTreeControl<TodoItemFlatNode>;

  treeFlattener: MatTreeFlattener<TodoItemNode, TodoItemFlatNode>;

  dataSource: MatTreeFlatDataSource<TodoItemNode, TodoItemFlatNode>;

  /** The selection for checklist */
  checklistSelection = new SelectionModel<TodoItemFlatNode>(true /* multiple */);
  
  @Input() selectedTasks:ODTask[];

  constructor(private database: ChecklistDatabase,
              private programsService: ProgramsService,
              private operationsService: OperationsService) {
    this.treeFlattener = new MatTreeFlattener(this.transformer, this.getLevel, this.isExpandable, this.getChildren);
    this.treeControl = new FlatTreeControl<TodoItemFlatNode>(this.getLevel, this.isExpandable);
    this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

    database.dataChange.subscribe(data => {
      this.dataSource.data = data;
    });
  }
  
  groupBy(array, key) {
    // Return the end result
    return array.reduce((result, currentValue) => {
      // If an array already present for key, push it to the array. Else create an array and push the object
      (result[currentValue[key]] = result[currentValue[key]] || []).push(
        currentValue
      );
      // Return the current iteration `result` value, this will be taken as next iteration `result` value and accumulate
      return result;
    }, {}); // empty object is the initial value for result object
  }

  ngOnInit()  {

    this.operationsService.getODTasks()
     
       .subscribe( (results:ODTask[]) =>{
       
         const taskByCategory = this.groupBy(results, 'CategoryGroup');
        
         let arr: TodoItemNode[] = [];

         for (let key in taskByCategory) {
           
           //var keyAsinteger = parseInt(key, 10);

           let todoItemNode = {
            // item: this.operationsService.stringOfEnum(CategoryGroup, keyAsinteger),
             item: key,
             children: null
           }

           let tasks = taskByCategory[key];
  
           let childrenTasksArr: any [] = [];

           tasks.forEach(elm => {
              childrenTasksArr.push({item:elm.Name, ODTask: elm});
           });
          
           todoItemNode.children = childrenTasksArr;

           arr.push(todoItemNode);
         }

         this.dataSource.data = arr;

         this.treeControl.expandAll();
    }); 
  }

  getLevel = (node: TodoItemFlatNode) => node.level;

  isExpandable = (node: TodoItemFlatNode) => node.expandable;

  getChildren = (node: TodoItemNode): TodoItemNode[] => node.children;

  hasChild = (_: number, _nodeData: TodoItemFlatNode) => _nodeData.expandable;

  hasNoContent = (_: number, _nodeData: TodoItemFlatNode) => _nodeData.item === '';

  /**
   * Transformer to convert nested node to flat node. Record the nodes in maps for later use.
   */
  transformer = (node: TodoItemNode, level: number) => {
    const existingNode = this.nestedNodeMap.get(node);
    const flatNode = existingNode && existingNode.item === node.item
        ? existingNode
        : new TodoItemFlatNode();
    flatNode.item = node.item;
    flatNode.ODTask = node.ODTask
    flatNode.level = level;
    flatNode.expandable = !!node.children;
    this.flatNodeMap.set(flatNode, node);
    this.nestedNodeMap.set(node, flatNode);
    return flatNode;
  }

  /** Whether all the descendants of the node are selected */
  descendantsAllSelected(node: TodoItemFlatNode): boolean {
    const descendants = this.treeControl.getDescendants(node);
    return descendants.every(child => this.checklistSelection.isSelected(child));
  }

  /** Whether part of the descendants are selected */
  descendantsPartiallySelected(node: TodoItemFlatNode): boolean {
    const descendants = this.treeControl.getDescendants(node);
    const result = descendants.some(child => this.checklistSelection.isSelected(child));
    return result && !this.descendantsAllSelected(node);
  }

  /** Toggle the to-do item selection. Select/deselect all the descendants node */
  todoItemSelectionToggle(node: TodoItemFlatNode): void {
    this.checklistSelection.toggle(node);
    const descendants = this.treeControl.getDescendants(node);
    this.checklistSelection.isSelected(node)
      ? this.checklistSelection.select(...descendants)
      : this.checklistSelection.deselect(...descendants);
  }

  clickedItem(node) {
  
    if(!this.checklistSelection.isSelected(node)) {
      this.selectedTasks.push(node.ODTask);
    }
    else {
       
       let index = this.selectedTasks.indexOf(node.ODTask);
       if (index > -1) {
            this.selectedTasks.splice(index, 1);
       }
    }
  }

  // drop(event: CdkDragDrop<{title: string, poster: string}[]>) {
  //   moveItemInArray(this.movies, event.previousIndex, event.currentIndex);
  // }

  // drop(event: CdkDragDrop<string[]>) {

  //   moveItemInArray(this.selectedTasks, event.previousIndex, event.currentIndex);
  // }
}
