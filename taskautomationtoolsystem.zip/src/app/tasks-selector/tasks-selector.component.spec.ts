import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TasksSelectorComponent } from './tasks-selector.component';

describe('TasksSelectorComponent', () => {
  let component: TasksSelectorComponent;
  let fixture: ComponentFixture<TasksSelectorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TasksSelectorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TasksSelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
