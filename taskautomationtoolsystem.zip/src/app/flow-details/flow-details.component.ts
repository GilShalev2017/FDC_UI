import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { UIExecutingFlow} from "../models/UIExecutingFlow";
import { UIExecutingTask} from "../models/UIExecutingTask";
import { FlowsService } from "../services/flows.service";
import { OperationsService } from "../services/operations.service";
import { MatDialog } from '@angular/material/dialog';
import { DeleteFlowComponent } from '../delete-flow/delete-flow.component';
import { FlinkRunningJobsComponent } from '../flink-running-jobs/flink-running-jobs.component';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { AuthService } from './../auth/auth.service';
import { FlinkTaskPayload, FlinkTaskType } from "../models/FlinkTaskPayload";

@Component({
  selector: 'app-flow-details',
  templateUrl: './flow-details.component.html',
  styleUrls: ['./flow-details.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class FlowDetailsComponent implements OnInit {
  
  displayedColumns: string[] = ['Status', 'Name', 'Description', 'Duration', 'Finished', 'actions'];
  dataSource: UIExecutingTask[] = [];
  expandedElement: UIExecutingTask | null;
  _intervalId: number;
  
  @Input() activeFlow: UIExecutingFlow;
  @Output() flowDeleted: EventEmitter<UIExecutingFlow> = new EventEmitter<UIExecutingFlow>();

  constructor(public flowsService: FlowsService,
              public operationsService: OperationsService,
              public auth: AuthService,
              public dialog: MatDialog) { }

  ngOnInit() {
    
    if(this.activeFlow != null){
      this.dataSource = this.activeFlow.UITasks;
    }

    if(this.auth.isProductionUser()==true) {
      this._intervalId = window.setInterval( () => 
            {
              this.getJobsOverview()
            }, 2000);
    }

  }

  startFlow() {
    this.operationsService.startFlow(this.activeFlow);
  }

  stopFlow() {
    this.operationsService.stopFlow(this.activeFlow);
  }

  deleteFlow() {
     const dialogRef = this.dialog.open(DeleteFlowComponent, {
      data: this.activeFlow
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        this.flowDeleted.emit(this.activeFlow);
        this.flowsService.getAllFlows();
      }
    });
  }

   editFlow() {

  }

   getJobsOverview(): void {
    let flinkTaskPayload: FlinkTaskPayload = {
            FlinkTaskType: FlinkTaskType.JobsOverview,
            DeploymentId: this.operationsService.selectedDeploymentId
          }

    this.operationsService.startFlinkTask(flinkTaskPayload);
  }

  runSingleTask(row: UIExecutingTask) {
      if (event) {
        event.stopPropagation();
      } 
      this.operationsService.startTask(row.ODTask.Id);
  }
}
