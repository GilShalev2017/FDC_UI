import { Component, OnInit,Injectable, ViewChild } from '@angular/core';
import {OperationsService} from "../services/operations.service";
import {FlowsService} from "../services/flows.service";
import {ProgramsService} from "../services/programs.service";
import {Subscription} from "rxjs";
import {ODTask} from "../models/ODTask";
import {ODProgram} from "../models/ODProgram";
import {ODFlow} from "../models/ODFlow";
import {UIExecutingFlow} from "../models/UIExecutingFlow";
import {CategoryGroup} from '../models/ODProgram';
import {BehaviorSubject, Observable, of as observableOf} from 'rxjs';
import {MatListModule, MatSelectionList, MatListOption} from '@angular/material/list';
import {SelectionModel} from '@angular/cdk/collections';
import { AuthService } from './../auth/auth.service';

@Component({
  selector: 'app-flow-view',
  templateUrl: './flow-view.component.html',
  styleUrls: ['./flow-view.component.css']
})
export class FlowViewComponent implements OnInit {
  @ViewChild(MatSelectionList, {static: true})
  private selectionList: MatSelectionList;

  displayFlowFlag:boolean = false;
  displayWizardFlag:boolean = false;
  selectedFlow:UIExecutingFlow;
  newFlow:ODFlow;
  
  constructor(public flowsService: FlowsService,
              public programsService: ProgramsService,
              public auth: AuthService,
              public operationsService: OperationsService) { }

  ngOnInit()  {

    this.refresh();
   
  }

  addNewFlow() {
    this.displayWizardFlag = true;
    this.displayFlowFlag = false;
    this.newFlow={};
  }

  refresh() {
    this.flowsService.getAllFlows()
       .subscribe( res =>{
          this.selectedFlow = null;
          this.displayFlowFlag = false;
        });

    //TODO remove it later
   
   // this.operationsService.getFilteredFlows()
    this.operationsService.getAllFlows()
       .subscribe( res =>{
          
          // this.selectedFlow = this.flowsService.availableFlows[0];
          // this.displayFlow(this.selectedFlow); 
        });
  }

  displayFlow(flow: UIExecutingFlow) {
      this.displayFlowFlag = true;
      this.displayWizardFlag = false;
      this.selectedFlow = flow;

      //If flow is running display its current status
      if( this.operationsService.currentRunningFlow != null) {
        if(this.selectedFlow.ODFlow.Id === this.operationsService.currentRunningFlow.ODFlow.Id)

        this.selectedFlow = this.operationsService.currentRunningFlow;
      }
  }

  onFlowDeleted(flow: UIExecutingFlow) {
    this.refresh();
  }

  onFlowSaved(flow: ODFlow) {
    this.refresh();
  }
}