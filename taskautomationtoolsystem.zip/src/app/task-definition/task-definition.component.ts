import {Component, EventEmitter, Inject, Input, OnInit, Output} from '@angular/core';
import {ODTask} from "../models/ODTask";
import {BsModalRef} from "ngx-bootstrap";
import {OperationsService} from "../services/operations.service";
import {ODProgram} from "../models/ODProgram";

@Component({
  selector: 'app-task-definition',
  templateUrl: './task-definition.component.html',
  styleUrls: ['./task-definition.component.css']
})
export class TaskDefinitionComponent implements OnInit {

  @Input() modalRef: BsModalRef;
  @Input() editedTask: ODTask;
  @Output() taskSaved: EventEmitter<ODTask> = new EventEmitter<ODTask>();
  @Output() taskDuplicated: EventEmitter<ODTask> = new EventEmitter<ODTask>();
  @Input() isEditMode: boolean;

  constructor(public operationsService: OperationsService) {}

  ngOnInit() {
    this.getODPrograms();
  }

  getODPrograms() {
    this.operationsService.getODPrograms()
      .subscribe( (odps: ODProgram[]) => {
    });
  }

  saveTask() {
    this.taskSaved.emit(this.editedTask);
    this.modalRef.hide();
  }

  duplicateTask() {
    this.taskDuplicated.emit(this.editedTask);
    this.modalRef.hide();
  }
}
