import { Component, OnInit, Input } from '@angular/core';
import {UIExecutingTask} from "../models/UIExecutingTask";

@Component({
  selector: 'app-task-card',
  templateUrl: './task-card.component.html',
  styleUrls: ['./task-card.component.css']
})
export class TaskCardComponent implements OnInit {

  @Input() activeTask: UIExecutingTask;

  constructor() { }

  ngOnInit() {
  }

}
