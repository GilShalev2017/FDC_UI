import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { ProgramsService } from "../services/programs.service";
import { FormControl, Validators } from '@angular/forms';
import { ODProgram } from "../models/ODProgram";

@Component({
  selector: 'app-edit-program',
  templateUrl: './edit-program.component.html',
  styleUrls: ['./edit-program.component.css']
})
export class EditProgramComponent  {

  constructor(public dialogRef: MatDialogRef<EditProgramComponent>,
              @Inject(MAT_DIALOG_DATA) public data: ODProgram, public dataService: ProgramsService) { }

  formControl = new FormControl('', [
    Validators.required
    // Validators.email,
  ]);

  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  stopEdit(): void {
    this.dataService.updateProgram(this.data);
  }
}
