import { Component, OnInit, OnDestroy } from '@angular/core';
import { OperationsService } from "../services/operations.service";
import { FlinkTaskPayload } from "../models/FlinkTaskPayload";
import { FlinkTaskType } from "../models/FlinkTaskPayload";
import { FlinkJob } from "../models/FlinkJob";

@Component({
  selector: 'app-flink-running-jobs',
  templateUrl: './flink-running-jobs.component.html',
  styleUrls: ['./flink-running-jobs.component.css']
})
export class FlinkRunningJobsComponent implements OnInit, OnDestroy {

  displayedColumns: string[] = ['jid', 'name', 'startTime', 'duration', 'endTime', 'tasks', 'state', 'actions' ];
  filteredData: FlinkJob[] = [];
  cancelButtonText: string = "Cancel Job";

  constructor(public operationsService: OperationsService) { }

  ngOnInit() {
    this.filteredData = this.operationsService.flinkJobs;
  }

  ngOnDestroy() {
  }


  stopFlinkJob(job: FlinkJob) {
    //this.cancelButtonText = 'Cancelling';
 
    let flinkTaskPayload: FlinkTaskPayload = {
            FlinkTaskType: FlinkTaskType.StopJob,
            JobId: job.jid,
            DeploymentId: this.operationsService.selectedDeploymentId
        }

    this.operationsService.startFlinkTask(flinkTaskPayload);
  }

}
