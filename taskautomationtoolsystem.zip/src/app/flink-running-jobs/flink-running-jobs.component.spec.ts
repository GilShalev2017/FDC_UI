import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlinkRunningJobsComponent } from './flink-running-jobs.component';

describe('FlinkRunningJobsComponent', () => {
  let component: FlinkRunningJobsComponent;
  let fixture: ComponentFixture<FlinkRunningJobsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlinkRunningJobsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlinkRunningJobsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
