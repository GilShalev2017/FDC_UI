import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { fromPromise } from 'rxjs/observable/fromPromise';
import { map, tap, catchError } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import Amplify, { Auth } from 'aws-amplify';
import { environment } from './../../environments/environment';

@Injectable()
export class AuthService {

  public loggedIn: BehaviorSubject<boolean>;
  public accessToken: string;
  public idToken: string;
  public isLoggedIn: boolean;
  public userGroups: string[] = [];
  
  constructor(private router: Router) {

     let amplify = {
      Auth: {
        region: 'eu-west-1',
        userPoolId: 'eu-west-1_o7p6k6QXM',
        userPoolWebClientId: '7sdvi8bfk3s8be453bha3q4545'
      }
    };

    // RENE
    // let amplify = {
    //   Auth: {
    //     region: 'us-east-1',
    //     userPoolId: 'us-east-1_YuSwcvMEa',
    //     userPoolWebClientId: '5la8ododr3csle9b1hd369h0r'
    //   }
    // };

    Amplify.configure(amplify);

    this.loggedIn = new BehaviorSubject<boolean>(false);
  }

  /** signup */
  public signUp(email, password): Observable<any> {
    return fromPromise(Auth.signUp(email, password));
  }

  /** confirm code */
  public confirmSignUp(email, code): Observable<any> {
    return fromPromise(Auth.confirmSignUp(email, code));
  }

  /** signin */
  public signIn(email, password): Observable<any> {
    return fromPromise(Auth.signIn(email, password))
      .pipe(
        tap(() => this.loggedIn.next(true))
      );
  }

  /** get authenticat state */
  public isAuthenticated(): Observable<boolean> {
    return fromPromise(Auth.currentAuthenticatedUser())
      .pipe(
        map(result => {
          this.loggedIn.next(true);
          this.accessToken = result.signInUserSession.accessToken.jwtToken;
          this.idToken = result.signInUserSession.idToken.jwtToken;
          this.userGroups = result.signInUserSession.idToken.payload['cognito:groups'];
          this.isLoggedIn = true;
          return true;
        }),
        catchError(error => {
          this.loggedIn.next(false);
          this.isLoggedIn = false;
          return of(false);
        })
      );
  }

  public getCurrentAuthenticatedUser():Observable<any> {
    return fromPromise(Auth.currentAuthenticatedUser())
          .pipe(
            map(result => {
              this.accessToken = result.signInUserSession.accessToken.jwtToken;
              return result;
            }),
            catchError(error => {
              return of(null);
            })
          );
  }

  /** signout */
  public signOut() {
    fromPromise(Auth.signOut())
      .subscribe(
        result => {
          this.loggedIn.next(false);
          //this.router.navigate(['/login']);
          this.router.navigate(['/login-form']);
        },
        error => console.log(error)
      );
  }
  
  public isProductionUser() {
     if(this.userGroups == null) {
       return false;
     }
     if(this.userGroups.includes("production_users")) {
       return true;
     }
     return false;
  }
}
