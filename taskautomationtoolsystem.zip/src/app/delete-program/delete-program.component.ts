import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ProgramsService } from "../services/programs.service";
import { ODProgram } from "../models/ODProgram";

@Component({
  selector: 'app-delete-program',
  templateUrl: './delete-program.component.html',
  styleUrls: ['./delete-program.component.css']
})
export class DeleteProgramComponent {

  constructor(public dialogRef: MatDialogRef<DeleteProgramComponent>,
              @Inject(MAT_DIALOG_DATA) public data: ODProgram,
              public dataService: ProgramsService)
  { }
  
  onNoClick(): void {
    this.dialogRef.close();
  }

  confirmDelete(): void {
    this.dataService.deleteODProgram(this.data).
     subscribe((res: boolean) => {

    });
  }
}
