import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatTreeModule } from '@angular/material/tree';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatListModule, MatListOption} from '@angular/material/list';
import { MatStepperModule} from '@angular/material/stepper';
import { MatInputModule, MatAutocompleteModule } from '@angular/material';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from "@angular/material/table";
import { MatDialogModule } from '@angular/material/dialog';
import { MatRadioModule } from '@angular/material/radio';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatGridListModule } from '@angular/material/grid-list';
import  { MatSelectModule } from '@angular/material/select';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { BootstrapLayoutComponent } from './bootstrap-layout/bootstrap-layout.component';
import { MyBootstrapLayoutComponent } from './my-bootstrap-layout/my-bootstrap-layout.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SocketIoModule, SocketIoConfig } from 'ngx-socket-io';
import { DocumentComponent } from './document/document.component';
import { DocumentListComponent } from './document-list/document-list.component';
import {DataService} from "./services/data.service";
import {MaterialDataService} from "./services/material-data.service";
import {MyWebSocketService} from "./services/my-web-socket.service";
import { TaskViewComponent } from './task-view/task-view.component';

import { DlDateTimeDateModule, DlDateTimePickerModule } from 'angular-bootstrap-datetimepicker';
import {MatDatepickerModule} from "@angular/material/datepicker";
import {MatNativeDateModule} from "@angular/material/core";
import {FontAwesomeModule} from "@fortawesome/angular-fontawesome";
import { TaskDefinitionComponent } from './task-definition/task-definition.component';

import {BsModalService, ModalModule} from 'ngx-bootstrap/modal';
import {OperationsService} from "./services/operations.service";
import {ProgramsService} from "./services/programs.service";
import {TasksService} from "./services/tasks.service";
import {FlowsService} from "./services/flows.service";

import { ConfirmationDialogComponent } from './confirmation-dialog/confirmation-dialog.component';

import { ToastrModule, ToastContainerModule  } from 'ngx-toastr';
import {DialogOverviewExampleDialog, YesNoDialogComponent} from './yes-no-dialog/yes-no-dialog.component';
import { MaterialTaskViewComponent } from './material-task-view/material-task-view.component';

import {AddDialogComponent} from './dialogs/add/add.dialog.component';
import {EditDialogComponent} from './dialogs/edit/edit.dialog.component';
import {DeleteDialogComponent} from './dialogs/delete/delete.dialog.component';
import {CollapseModule} from 'ngx-bootstrap/collapse';
import {ScrollToBottomDirective} from './directives/scroll-to-bottom.directive';
import { TasksCardViewComponent } from './tasks-card-view/tasks-card-view.component';
import { TaskCardComponent } from './task-card/task-card.component';
import { ProgramViewComponent } from './program-view/program-view.component';
import { AddProgramComponent } from './add-program/add-program.component';
import { DeleteProgramComponent } from './delete-program/delete-program.component';
import { EditProgramComponent } from './edit-program/edit-program.component';
// import {ScrollingModule} from '@angular/cdk/scrolling';
// import {CdkStepperModule} from '@angular/cdk/stepper';
// import {CdkTableModule} from '@angular/cdk/table';
// import {CdkTreeModule} from '@angular/cdk/tree';

// for HttpClient import:
import { LoadingBarHttpClientModule } from '@ngx-loading-bar/http-client';
// for Router import:
// import { LoadingBarRouterModule } from '@ngx-loading-bar/router';
// for Core import:
import { LoadingBarModule } from '@ngx-loading-bar/core';
import { TaskReportComponent } from './task-report/task-report.component';
import { TopologyViewComponent } from './topology-view/topology-view.component';
import { FlowViewComponent } from './flow-view/flow-view.component';

import { DragDropModule} from '@angular/cdk/drag-drop';
import { FlowsViewComponent } from './flows-view/flows-view.component';
import { AddFlowComponent } from './add-flow/add-flow.component';
import { EditFlowComponent } from './edit-flow/edit-flow.component';
import { DeleteFlowComponent } from './delete-flow/delete-flow.component';
import { TasksSelectorComponent } from './tasks-selector/tasks-selector.component';
import { FlowDetailsComponent } from './flow-details/flow-details.component';
import { StatusBarComponent } from './status-bar/status-bar.component';
import { TasksViewComponent } from './tasks-view/tasks-view.component';
import { FlinkFlowComponent } from './flink-flow/flink-flow.component';

const config: SocketIoConfig = { url: 'http://localhost:4444', options: {} };

/* Add Amplify imports */
// import { AmplifyUIAngularModule } from '@aws-amplify/ui-angular';
import Amplify from 'aws-amplify';
import { Auth } from 'aws-amplify';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { AuthService } from './auth/auth.service';
import { AuthGuard } from './auth/auth.guard';
import { LoginFormComponent } from './login-form/login-form.component';
import { FlinkRunningJobsComponent } from './flink-running-jobs/flink-running-jobs.component';
import { ConfigurationsComponent } from './configurations/configurations.component';
import { ConfigurationsTreeComponent } from './configurations-tree/configurations-tree.component';

import { NgJsonEditorModule } from 'ang-jsoneditor';
/*
Amplify.configure({
    Auth: {

        // REQUIRED only for Federated Authentication - Amazon Cognito Identity Pool ID
        // identityPoolId: 'XX-XXXX-X:XXXXXXXX-XXXX-1234-abcd-1234567890ab',

        // REQUIRED - Amazon Cognito Region
        region: 'eu-west-1',

        // OPTIONAL - Amazon Cognito Federated Identity Pool Region 
        // Required only if it's different from Amazon Cognito Region
        // identityPoolRegion: 'eu-west-1',

        // OPTIONAL - Amazon Cognito User Pool ID
        userPoolId: 'eu-west-1_o7p6k6QXM',

        // OPTIONAL - Amazon Cognito Web Client ID (26-char alphanumeric string)
        userPoolWebClientId: '7sdvi8bfk3s8be453bha3q4545',

        // OPTIONAL - Enforce user authentication prior to accessing AWS resources or not
        mandatorySignIn: false,

        // OPTIONAL - Configuration for cookie storage
        // Note: if the secure flag is set to true, then the cookie transmission requires a secure protocol
        // cookieStorage: {
        // // REQUIRED - Cookie domain (only required if cookieStorage is provided)
        //     domain: '.yourdomain.com',
        // // OPTIONAL - Cookie path
        //     path: '/',
        // // OPTIONAL - Cookie expiration in days
        //     expires: 365,
        // // OPTIONAL - Cookie secure flag
        // // Either true or false, indicating if the cookie transmission requires a secure protocol (https).
        //     secure: true
        // },

        // OPTIONAL - customized storage object
        // storage: new MyStorage(),

        // OPTIONAL - Manually set the authentication flow type. Default is 'USER_SRP_AUTH'
        // authenticationFlowType: 'USER_PASSWORD_AUTH',

        // OPTIONAL - Manually set key value pairs that can be passed to Cognito Lambda Triggers
        // clientMetadata: { myCustomKey: 'myCustomValue' },

         // OPTIONAL - Hosted UI configuration
        // oauth: {
        //     domain: 'https://tats.auth.eu-west-1.amazoncognito.com',
        //     scope: ['phone', 'email', 'profile', 'openid', 'aws.cognito.signin.user.admin'],
        //     redirectSignIn: 'http://localhost:4200/',
        //     redirectSignOut: 'http://localhost:4200/',
        //     responseType: 'code' // or 'token', note that REFRESH token will only be generated when the responseType is code
        // }
    }
});
*/

// You can get the current config object
// const currentConfig = Auth.configure();

@NgModule({
  declarations: [
    AppComponent,
    AddDialogComponent,
    EditDialogComponent,
    DeleteDialogComponent,
    HomeComponent,
    AboutComponent,
    BootstrapLayoutComponent,
    MyBootstrapLayoutComponent,
    DocumentComponent,
    DocumentListComponent,
    TaskViewComponent,
    TaskDefinitionComponent,
    ConfirmationDialogComponent,
    YesNoDialogComponent,
    DialogOverviewExampleDialog,
    MaterialTaskViewComponent,
    ScrollToBottomDirective,
    TasksCardViewComponent,
    TaskCardComponent,
    ProgramViewComponent,
    AddProgramComponent,
    DeleteProgramComponent,
    EditProgramComponent,
    TaskReportComponent,
    TopologyViewComponent,
    FlowViewComponent,
    FlowsViewComponent,
    AddFlowComponent,
    EditFlowComponent,
    DeleteFlowComponent,
    TasksSelectorComponent,
    FlowDetailsComponent,
    StatusBarComponent,
    TasksViewComponent,
    FlinkFlowComponent,
    SignupComponent,
    LoginComponent,
    LoginFormComponent,
    FlinkRunningJobsComponent,
    ConfigurationsComponent,
    ConfigurationsTreeComponent,
  ],
  imports: [
    // ScrollingModule,
    // CdkStepperModule,
    // CdkTableModule,
    // CdkTreeModule,

    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatIconModule,
    MatCardModule,
    MatButtonModule,
    MatProgressSpinnerModule,
    MatSidenavModule,
    MatTreeModule,
    MatCheckboxModule,
    MatProgressBarModule,
    MatListModule,
    MatStepperModule,
    SocketIoModule.forRoot(config),
    MatInputModule,
    MatAutocompleteModule,
    MatPaginatorModule,
    MatSortModule,
    MatTableModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatDialogModule,
    MatRadioModule,
    MatSlideToggleModule,
    MatTooltipModule,
    MatGridListModule,
    MatSelectModule,
    FormsModule,
    DlDateTimeDateModule,
    DlDateTimePickerModule,
    ModalModule.forRoot(),
    FontAwesomeModule,
    ToastrModule.forRoot(),
    ToastContainerModule,
    ReactiveFormsModule,
    CollapseModule.forRoot(),

     // for HttpClient use:
    LoadingBarHttpClientModule,
    // for Router use:
    // LoadingBarRouterModule,
    // for Core use:
    LoadingBarModule,
    DragDropModule,
    NgJsonEditorModule,
    //AmplifyUIAngularModule,
  ],
  entryComponents: [
    AddDialogComponent,
    EditDialogComponent,
    DeleteDialogComponent,
    AddProgramComponent,
    DeleteProgramComponent,
    EditProgramComponent,
    AddFlowComponent,
    EditFlowComponent,
    DeleteFlowComponent,
  ],
  providers: [DataService,
              MaterialDataService, 
              MyWebSocketService,
              BsModalService,
              OperationsService,
              ProgramsService,
              TasksService, 
              FlowsService,
              AuthService,
              AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
