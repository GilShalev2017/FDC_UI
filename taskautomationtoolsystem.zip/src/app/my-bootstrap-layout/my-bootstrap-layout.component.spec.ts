import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyBootstrapLayoutComponent } from './my-bootstrap-layout.component';

describe('MyBootstrapLayoutComponent', () => {
  let component: MyBootstrapLayoutComponent;
  let fixture: ComponentFixture<MyBootstrapLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyBootstrapLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyBootstrapLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
