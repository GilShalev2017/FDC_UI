import {MatTreeFlatDataSource, MatTreeFlattener} from '@angular/material/tree';
import {MyWebSocketService} from "../services/my-web-socket.service";
import {DataService} from "../services/data.service";
import {Subscription} from "rxjs";
import {MatSort} from "@angular/material/sort";
import {MatTableDataSource} from "@angular/material/table";
import {MatPaginator} from "@angular/material/paginator";
import {FlatTreeControl} from "@angular/cdk/tree";
import {Component, OnDestroy, OnInit, ViewChild} from "@angular/core";
import {ODTask} from "../models/ODTask";

export interface UserData {
  id: string;
  name: string;
  progress: string;
  color: string;
}

/** Constants used to fill up our data base. */
const COLORS: string[] = [
  'maroon', 'red', 'orange', 'yellow', 'olive', 'green', 'purple', 'fuchsia', 'lime', 'teal',
  'aqua', 'blue', 'navy', 'black', 'gray'
];
const NAMES: string[] = [
  'Maia', 'Asher', 'Olivia', 'Atticus', 'Amelia', 'Jack', 'Charlotte', 'Theodore', 'Isla', 'Oliver',
  'Isabella', 'Jasper', 'Cora', 'Levi', 'Violet', 'Arthur', 'Mia', 'Thomas', 'Elizabeth'
];

/** Flat node with expandable and level information */
interface ExampleFlatNode {
  expandable: boolean;
  name: string;
  level: number;
}

@Component({
  selector: 'app-my-bootstrap-layout',
  templateUrl: './my-bootstrap-layout.component.html',
  styleUrls: ['./my-bootstrap-layout.component.css']
})
export class MyBootstrapLayoutComponent implements OnInit {//}, OnDestroy {

  private events: Object;
  private deployments: Object;
  private games: Object;
  tasks: ODTask[];

  displayedColumns: string[] = ['id', 'name', 'progress', 'color'];
  dataSource2: MatTableDataSource<UserData>;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  // private _transformer = (node: FoodNode, level: number) => {
  //   return {
  //     expandable: !!node.children && node.children.length > 0,
  //     name: node.name,
  //     level: level,
  //   };
  // }

  treeControl = new FlatTreeControl<ExampleFlatNode>(
    node => node.level, node => node.expandable);

  // treeFlattener = new MatTreeFlattener(
  //   this._transformer, node => node.level, node => node.expandable, node => node.children);
  //
  // dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

  stockQuote: number;
  sub: Subscription;

  constructor(private myWebSocketService: MyWebSocketService, private dataService: DataService) {
    //this.dataSource.data = TREE_DATA;
    // Create 100 users
    const users = Array.from({length: 100}, (_, k) => createNewUser(k + 1));
    // Assign the data to the data source for the table to render
    this.dataSource2 = new MatTableDataSource(users);
  }

  hasChild = (_: number, node: ExampleFlatNode) => node.expandable;

  applyFilter(filterValue: string) {
    this.dataSource2.filter = filterValue.trim().toLowerCase();

    if (this.dataSource2.paginator) {
      this.dataSource2.paginator.firstPage();
    }
  }

  ngOnInit() {

    this.dataSource2.paginator = this.paginator;
    this.dataSource2.sort = this.sort;

     // this.sub = this.dataService.getQuotes()
     //  .subscribe(quote => {
     //    this.stockQuote = quote;
     //  });

    this.getAllTasks();
  }

  getAllTasks() {

    this.tasks = [];

    this.myWebSocketService.loadTaskList()
      .subscribe( (arrivedData: ODTask[]) => {
        this.tasks = arrivedData;
      });
  }

  // ngOnDestroy() {
  //   // this.sub.unsubscribe();
  // }

  runScript() {

  }


}

/** Builds and returns a new User. */
function createNewUser(id: number): UserData {
  const name = NAMES[Math.round(Math.random() * (NAMES.length - 1))] + ' ' +
    NAMES[Math.round(Math.random() * (NAMES.length - 1))].charAt(0) + '.';

  return {
    id: id.toString(),
    name: name,
    progress: Math.round(Math.random() * 100).toString(),
    color: COLORS[Math.round(Math.random() * (COLORS.length - 1))]
  };
}


// this.myWebSocketService.loadEvents()
//   .subscribe(result => {
//     this.events = result;
//     });

// this.myWebSocketService.loadDeployments()
//   .subscribe(result => {
//     this.deployments = result;
//   });

// this.myWebSocketService.loadGames()
//   .subscribe(result => {
//     this.games = result;
//   });

/**
 * Food data with nested structure.
 * Each node has a name and an optiona list of children.
 */
// interface FoodNode {
//   name: string;
//   children?: FoodNode[];
// }
//
// const TREE_DATA: FoodNode[] = [
//   {
//     name: 'Multi-View',
//     children: [
//       {name: 'Windows'},
//       {name: 'Ubuntu'},
//       {name: 'IOS'},
//     ]
//   },
//   {
//     name: 'Reconstruction',
//     children: [
//       {name: 'Windows'},
//       {name: 'Ubuntu'},
//       {name: 'IOS'},
//     ]
//   },
//   {
//     name: 'Decoder',
//     children: [
//       {
//         name: '30 FPS',
//         children: [
//           {name: '4 Threads'},
//           {name: '8 Threads'},
//         ]
//       }, {
//         name: '20 FPS',
//         children: [
//           {name: 'Flink Cluster'},
//           {name: 'Stand Alone'},
//         ]
//       },
//     ]
//   },
// ];
