import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MaterialTaskViewComponent } from './material-task-view.component';

describe('MaterialTaskViewComponent', () => {
  let component: MaterialTaskViewComponent;
  let fixture: ComponentFixture<MaterialTaskViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaterialTaskViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaterialTaskViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
