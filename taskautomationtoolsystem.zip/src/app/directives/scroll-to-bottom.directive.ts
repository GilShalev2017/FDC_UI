import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appScrollToBottom]'
})
export class ScrollToBottomDirective {

  _element: ElementRef;

  constructor(element: ElementRef) { 

     this._element = element;
   
     var self = this;
   
     setInterval(function() {self._element.nativeElement.scrollIntoView({behavior: "smooth", block: "end"});}, 1000);
   
  }
}
