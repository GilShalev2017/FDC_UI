/*
import { Injectable, EventEmitter } from "@angular/core";
import * as signalR from "@aspnet/signalr";
import { SignalViewModel } from "../models/signal-view-model";
import { ODTask } from "../models/ODTask";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, tap } from 'rxjs/operators';
import {Observable} from "rxjs";

@Injectable({
  providedIn: "root"
})
export class SignalRService {

  private urlSignalREndpoint = "http://localhost:63291/api/v1/signals/deliverypoint";
  private hubConnection: signalR.HubConnection;
  private hubStreamingConnection: signalR.HubConnection;
  signalReceived = new EventEmitter<SignalViewModel>();
  taskStartSignalReceived = new EventEmitter<ODTask>();
  taskStopSignalReceived = new EventEmitter<ODTask>();

  public logLines: string [] = [];
  public activeTasks: ODTask [] = [];
  public completedTasks: ODTask [] = [];
  public scheduledTasks: ODTask [] = [];

  public connectedToSignalServer :boolean = false;

  constructor(private httpClient: HttpClient) {

  }

  runTask(task: ODTask) {
    //this.buildStreamingConnection();

    this.hubStreamingConnection
      .stop() .then(() => {
          this.startLaunchTaskStreamingConnection(task);
          this.activeTasks.unshift(task);
        })
      .catch(err => {
        console.log("Error while stopping connection: " + err);
      });
  }

  stopTask(task: ODTask) {
    //this.startStopTaskStreamingConnection(task);
    //this.registerToStopTaskEvents(task);

    this.sendStopTaskMessageToSignalRServer(task)
      .subscribe((task: ODTask) => {
        this.logLines.push("Received Stop Task Signal");
      });
  }

  private startStopTaskStreamingConnection = (task: ODTask) => {
    this.hubStreamingConnection
      .start()
      .then(() => {
        console.log("Streaming Connection Started...");
        this.logLines.push("Streaming Connection Started...");
        this.registerToStopTaskEvents(task);
      })
      .catch(err => {
        console.log("Error while starting connection: " + err);
        //if you get error try to start connection again after 3 seconds.
        setTimeout(function() {
          this.startStopTaskStreamingConnection();
        }, 3000);
      });
  };

  private startLaunchTaskStreamingConnection = (task: ODTask) => {

    this.hubStreamingConnection
      .start()
      .then(() => {
        console.log("Streaming Connection Started...");
        this.logLines.push("Streaming Connection Started...");
        this.registerToLaunchTaskEvents(task);
      })
      .catch(err => {
        console.log("Error while starting connection: " + err);
        //if you get error try to start connection again after 3 seconds.
        setTimeout(function() {
          this.startLaunchTaskStreamingConnection();
        }, 3000);
      });
  };

  private registerToStopTaskEvents(task : ODTask) {
    this.hubStreamingConnection.stream("StopTask", task)
      .subscribe({
        next: (item) => {
          this.logLines.push(item);
        },
        complete: () => {
          this.logLines.push("STOP COMPLETE !!!");

        },
        error: (err) => {
          this.logLines.push("STOPPING ERROR !!!");
        },
      });
  }

  private registerToLaunchTaskEvents(task : ODTask) {
    this.hubStreamingConnection.stream("LaunchTask", task)
      .subscribe({
        next: (item) => {
          if(item.includes("ProcessID=")) {
            let processId = item.substring(10, item.length);
            // task.ProcessId = processId;
          }

          this.logLines.push(item);
        },
        complete: () => {
          this.logLines.push("complete !!!");

          const index = this.activeTasks.indexOf(task);
          if (index > -1) {
            this.activeTasks.splice(index, 1);
          }
          // task.RunResult="Finished";
          let currentdate = new Date();
          let datetime = "Last Sync: " + currentdate.getDate() + "/"
            + (currentdate.getMonth()+1)  + "/"
            + currentdate.getFullYear() + " @ "
            + currentdate.getHours() + ":"
            + currentdate.getMinutes() + ":"
            + currentdate.getSeconds();
          // task.RunEnd = datetime;
          this.completedTasks.unshift(task);
        },
        error: (err) => {
          this.logLines.push("ERROR !!!");
        },
      });
  }

  public displayStreamingLog() {
    this.buildStreamingConnection();
    this.startStreamingConnection();
  }

  private buildConnection = () => {
    this.hubConnection = new signalR.HubConnectionBuilder()
      .withUrl("http://localhost:63291/signalHub") //use your api adress here and make sure you use right hub name.
      .build();
  };

  private buildStreamingConnection = () => {
    this.hubStreamingConnection = new signalR.HubConnectionBuilder()
      .withUrl("http://localhost:63291/streamHub") //use your api adress here and make sure you use right hub name.
      .build();
  };

  private startConnection = () => {
    this.hubConnection
      .start()
      .then(() => {
        console.log("Connection Started...");
        this.registerSignalEvents();
      })
      .catch(err => {
        console.log("Error while starting connection: " + err);
        //if you get error try to start connection again after 3 seconds.
        setTimeout(function() {
          this.startConnection();
        }, 3000);
      });
  };

  private startStreamingConnection = () => {
    this.hubStreamingConnection
      .start()
      .then(() => {
        console.log("Streaming Connection Started...");
        this.logLines.push("Streaming Connection Started...");
        this.registerStreamingSignalEvents();
      })
      .catch(err => {
        console.log("Error while starting connection: " + err);
        //if you get error try to start connection again after 3 seconds.
        setTimeout(function() {
          this.startStreamingConnection();
        }, 3000);
      });
  };

  private registerSignalEvents() {
    this.hubConnection.on("SignalMessageReceived", (data: SignalViewModel) => {
      this.signalReceived.emit(data);
    });

    this.hubConnection.on("StartTaskSignalMessageReceived", (data: ODTask) => {
      this.taskStartSignalReceived.emit(data);
    });

    this.hubConnection.on("StopTaskSignalMessageReceived", (data: ODTask) => {
      this.taskStopSignalReceived.emit(data);
    });
  }

  private registerStreamingSignalEvents() {
    // this.hubStreamingConnection.stream("DelayCounter", 500)
    this.hubStreamingConnection.stream("MyDelayCounter", 500)
      .subscribe({
        next: (item) => {
          // var li = document.createElement("li");
          // li.textContent = item;
          // document.getElementById("messagesList").appendChild(li);
          this.logLines.push(item);
          console.log("subscribe !!!");
        },
        complete: () => {
          this.logLines.push("complete !!!");
          console.log("complete !!!");
        },
        error: (err) => {
          // var li = document.createElement("li");
          // li.textContent = err;
          // document.getElementById("messagesList").appendChild(li);
          this.logLines.push("ERROR !!!");
          console.log("ERROR !!!");
        },
      });  }

  sendStopTaskMessageToSignalRServer(task :ODTask) {

    let task2: ODTask = {
      "Id": task.Id,
      "Name": task.Name,
      "Description": "TaskDescription",
      "ExecutedProgram": "ExecutedProgram",
      "ExecutedProgramParams": "ExecutedProgramParams",
      "WorkingDirectory": "WorkingDirectory",
      "ReportStdOut":true
      // "ProcessId": task.ProcessId
    };

    return this.httpClient.post("http://signalmonitoringapi-dev.eu-west-1.elasticbeanstalk.com:63291/api/v1/signals/deliverypointstoptask",task2)
      // "http://localhost:63291/api/v1/signals/deliverypointstoptask",task2)
      .pipe(
        tap(res => {
          return res;
        }),
        catchError(this.handleError)
      );
  }

  sendNewTaskToSignalRServer(task :ODTask) {

    return this.httpClient.post("http://localhost:63291/api/v1/signals/deliverypoint2",task)
      .pipe(
        tap(res => {
          return res;
        }),
        catchError(this.handleError)
      );
  }

  cleanLogs() {
    //TODO better cleaning!
    this.logLines = [];
  }

  handleError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = body || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Observable.throw(errMsg);
  }
}
*/