import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable} from 'rxjs';
import {catchError, tap} from 'rxjs/operators';
import {ODTask} from '../models/ODTask';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';

@Injectable()
export class TasksService {
 
  private urlTaskGetterApi: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/taskmanager';
  private urlTaskInserterAPI: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/taskinserter';
  private urlTaskUpdateAPI: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/Dev/taskupdater'
  private urlTaskRemoverApi: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/Dev/taskremover';

  dataChange: BehaviorSubject<ODTask[]> = new BehaviorSubject<ODTask[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;

  constructor (private httpClient: HttpClient) {}

  get data(): ODTask[] {
    return this.dataChange.value;
  }

  getDialogData() {
    return this.dialogData;
  }

   getAllTasks(): void {
    this.httpClient.get<ODTask[]>(this.urlTaskGetterApi).subscribe(data => {
   
        this.dataChange.next(data);
      },
      (error: HttpErrorResponse) => {
        console.log (error.name + ' ' + error.message);
      });
  }
}