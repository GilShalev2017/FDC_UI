import { EventEmitter, Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpErrorResponse, HttpParams, HttpEventType, HttpHeaders } from '@angular/common/http';
import { throwError, Observable, BehaviorSubject } from 'rxjs';
import { retry, catchError, tap, map, last } from 'rxjs/operators';
import * as signalR from "@aspnet/signalr";
import { TaskPayload } from "../models/TaskPayload";
import { FlowPayload } from "../models/FlowPayload";
import { ODTask } from "../models/ODTask";
import { OperationalDocker } from "../models/OperationalDocker";
import { ODFlow } from "../models/ODFlow";
import { FlinkTaskPayload, FlinkTaskType } from "../models/FlinkTaskPayload";
import { FlinkJar } from "../models/FlinkJar";
import { FlinkJob } from "../models/FlinkJob";
import { UIExecutingFlow } from "../models/UIExecutingFlow";
import { ExecutingTaskStatus } from "../models/ExecutingTaskStatus";
import { ExecutingFlowStatus } from "../models/ExecutingFlowStatus";
import { ExecutingTaskData } from "../models/ExecutingTaskData";
import { UIExecutingTask } from "../models/UIExecutingTask";
import { ODProgram } from "../models/ODProgram";
import { Deployment } from "../models/Deployment";
import { HubConnectionState } from "@aspnet/signalr/dist/esm/HubConnection";
import { CategoryGroup } from '../models/ODProgram';
import { FlowsService} from "../services/flows.service";
import { AuthService } from './../auth/auth.service';
import { Auth } from 'aws-amplify';
import { fromPromise } from 'rxjs/observable/fromPromise';

@Injectable({
  providedIn: 'root'
})
export class OperationsService {

  public HUB_URL = //"http://localhost:61649/ChatHub"
                    "http://63.33.241.11:5000/TaskProcessHub";
                   
                   // "https://a01fdcontr26j7q-fdcontroller-hub.deployment.fd19.sports.intel.com/"; //For Rene

                   // "http://localhost:54797/TaskProcessHub";
                   //"https://localhost:44374/TaskProcessHub";
  public hubConnection: signalR.HubConnection;

  private urlTaskGetterApi: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/taskmanager';
  private urlTaskInserterAPI: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/taskinserter';
  private urlTaskUpdateAPI: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/taskupdater'
  private urlTaskRemoverApi: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/taskremover';

  private urlProgramGetterApi: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/program-manager';
  private urlProgramInserterAPI: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/program-inserter';
  private urlProgramGetUrlAPI: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/program-uploader';

  private urlDeploymentGettrApi: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/deployment-manager';

  private urlFlowGetterApi: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/flows-manager';

  private urlFlinkJarGetterApi: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/flink-jars-manager';
  
  private urlConfigGetterAPI:string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/configuration-manager';

  public connectedToHubServer: boolean = false;
  public registeredToHubServer: boolean = false;
  public availableTasks: ODTask[] = [];
  public availableFlows: UIExecutingFlow[];
  public activeTasks: UIExecutingTask[] = [];
  public odPrograms: ODProgram[] = [];
  public availableOPDockers: OperationalDocker[] = []; //per deployment
  public registeredWorkers: OperationalDocker[] = []; //not in use
  public workerConnectedDeployments:  OperationalDocker[] = []; //all conneted deployments
  public configurations: any[] = [];
  // public connectedClients: string[];
  public availableJars: string[];
  public deployedFlinkJars: string[] = [];
  public runningJobs: string[] = [];
  public selectedDeploymentId: string;
  public activeDeployments: Deployment[];
  public currentRunningFlow: UIExecutingFlow;
  public flinkJobs: FlinkJob[] = [];
  public _isUploadingToFlink:boolean = false;
  public _isUploadedToFlink:boolean = false;
  public currentConfigContent:any;

  dataChange: BehaviorSubject<ODProgram[]> = new BehaviorSubject<ODProgram[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;
  public deploymentSelectionChanged: BehaviorSubject<boolean> = new BehaviorSubject(false);

  constructor(private httpClient: HttpClient, private authService: AuthService) {
    
  }

  public hubConnectionInit () {

    this.buildConnection();

    this.hubConnection.on("OnUIRegisteredStatus", (status: string) => {
      console.log("UI received 'OnUIRegisteredStatus': " + status);
      this.registeredToHubServer = true;

      this.getOPDockers();
    });

    this.hubConnection.on("OnTaskStatusReport", (executingTaskStatus: ExecutingTaskStatus) => {
      this.updateReportedStatus(executingTaskStatus);
    });

    this.hubConnection.on("OnFlowStatusReport", (executingFlowStatus: ExecutingFlowStatus) => {
      this.updateFlowReportedStatus(executingFlowStatus);
    });

    this.hubConnection.on("OutputDataReceived", (executingTaskData: ExecutingTaskData) => {
      this.updateStdoutData(executingTaskData);
    });

    this.hubConnection.on("OnRegisteredWorkerStatus", (worker: OperationalDocker) => {
      this.registeredWorkers.push(worker);
    });

     this.hubConnection.on("OnOperationalDockerListReceived", (dockers: OperationalDocker[]) => {
      this.availableOPDockers = dockers;
    });
 
    this.hubConnection.on("OnWorkerConnectedDeploymentsReceived", (workerConnectedDeployments: OperationalDocker[]) => {
      this.workerConnectedDeployments = workerConnectedDeployments;
    });
    
    this.hubConnection.onclose(() => {

      //  this.connectedToHubServer = false;
      //  this.startConnection();
      //  this.registerUI();
    });

    this.startConnection();

    this.registerUI();
  }

  private updateFlowReportedStatus(executingFlowStatus: ExecutingFlowStatus) {
    this.currentRunningFlow.ExecutingFlowStatus = executingFlowStatus;
  }

  private updateReportedStatus(executingTaskStatus: ExecutingTaskStatus) {

    if (executingTaskStatus.statusString == "ErrorDataReceived" || executingTaskStatus.statusString == "TaskCompletedWithError" || executingTaskStatus.statusString == "TaskStoppedError") {
      console.log("UI received: " + executingTaskStatus.statusString + " from executer: " + executingTaskStatus.executerId + " ErrorData was: " + executingTaskStatus.errorData);
    }
    else {
      console.log("UI received: " + executingTaskStatus.statusString + " from executer: " + executingTaskStatus.executerId);
    }

    if (executingTaskStatus.statusString == "TaskStarting") { //this case is special

      let foundODTask = this.availableTasks.find(function (element) {
        return element.Id == executingTaskStatus.taskId;
      });

      if (foundODTask != null) {
        let uiExecutingTask = {
          "ODTask": foundODTask,
          "ExecutingTaskStatus": executingTaskStatus,
          "expanded": false,
          "StdOut": []
        }
        this.activeTasks.push(uiExecutingTask);
      }

      // Find task of flow
      if (this.currentRunningFlow != null) {

        let foundTaskInFlow = this.currentRunningFlow.UITasks.find(function (element) {
          return element.ODTask.Id == executingTaskStatus.taskId;
        });

        if (foundTaskInFlow != null) {
          foundTaskInFlow.ExecutingTaskStatus = executingTaskStatus;
          foundTaskInFlow.StdOut = [];
        }
      }
    }
    else {
      let foundActiveTask = this.activeTasks.find(function (element) {
        return element.ExecutingTaskStatus.executerId == executingTaskStatus.executerId;
      });

      if (foundActiveTask != null) {
        foundActiveTask.ExecutingTaskStatus = executingTaskStatus;

        if (executingTaskStatus.statusString == "ErrorDataReceived" || executingTaskStatus.statusString == "TaskCompletedWithError" || executingTaskStatus.statusString == "TaskStoppedError") {
          foundActiveTask.StdOut.unshift(executingTaskStatus.errorData);
        }
      }

      // Find task of flow
      if (this.currentRunningFlow != null) {

        let foundActiveTaskInFlow = this.currentRunningFlow.UITasks.find(function (element) {
          return element.ExecutingTaskStatus.executerId == executingTaskStatus.executerId;
        });

        if (foundActiveTaskInFlow != null) {
          foundActiveTaskInFlow.ExecutingTaskStatus = executingTaskStatus;

          if (executingTaskStatus.statusString == "ErrorDataReceived" || executingTaskStatus.statusString == "TaskCompletedWithError" || executingTaskStatus.statusString == "TaskStoppedError") {
            foundActiveTaskInFlow.StdOut.unshift(executingTaskStatus.errorData);
          }
        }
      }
    }
  }

  private updateStdoutData(executingTaskData: ExecutingTaskData) {
    console.log("UI received 'OutputDataReceived' from executer: " + executingTaskData.executerId + " message line was: " + executingTaskData.data);
    let foundActiveTask = this.activeTasks.find(function (element) {
      return element.ExecutingTaskStatus.executerId == executingTaskData.executerId;
    });

    if (foundActiveTask != null) {
      if(executingTaskData.data == null || executingTaskData.data == "" ){
        executingTaskData.data = " ";
      }
      foundActiveTask.StdOut.unshift(executingTaskData.data);
    }

    // Find task of flow
    if (this.currentRunningFlow != null) {

      if (this.currentRunningFlow.UITasks != null) {
        let foundActiveTaskInFlow = this.currentRunningFlow.UITasks.find(function (element) {
          if (element.ExecutingTaskStatus == null) {
            return null;
          }
          return element.ExecutingTaskStatus.executerId == executingTaskData.executerId;
        });

        if (foundActiveTaskInFlow != null) {
          if(executingTaskData.data == null || executingTaskData.data == ""){
            executingTaskData.data = " ";
          }
          foundActiveTaskInFlow.StdOut.unshift(executingTaskData.data);
        }
      }
    }
    else  //check out if task run under a flow and if flow doesn't exist create it
    {
      if (executingTaskData.flowExecuterId != null) { //running in context of a flow

        let foundUiFlow = this.availableFlows.find(function (element) {
          return element.ODFlow.Id == executingTaskData.flowId;
        });
    
        if(foundUiFlow != null) {

           this.currentRunningFlow = foundUiFlow;
           if(this.currentRunningFlow.ExecutingFlowStatus == null) {
            this.currentRunningFlow.ExecutingFlowStatus = new ExecutingFlowStatus();
            this.currentRunningFlow.ExecutingFlowStatus.flowExecuterId = executingTaskData.flowExecuterId;
          }
        } 
      }
    }

    this.HandleFlinkTasks(executingTaskData);
  }
 
  private HandleFlinkTasks(executingTaskData: ExecutingTaskData) {
    
    if(executingTaskData.data != null) {

      if(executingTaskData.flinkTaskType == FlinkTaskType.JobsOverview) {

        if(executingTaskData.data.includes('{"jobs":[{"')) {
          // "jobs")) {
          
          const jobsStatuses = JSON.parse(executingTaskData.data);
      
          if(jobsStatuses.jobs != null && executingTaskData.deploymentId == this.selectedDeploymentId) {
            
            //TODO add and update, not overrun

            this.flinkJobs = [];//jobsStatuses.jobs;
            
              jobsStatuses.jobs.forEach( arrivedJob => {
              
                let uiJob: FlinkJob = {
                  "jid": arrivedJob.jid,
                  "name": arrivedJob.name,
                  "state": arrivedJob.state,
                  "startTime": arrivedJob["start-time"],
                  "endTime": arrivedJob["end-time"],
                  "duration": this.msToTime(arrivedJob.duration),
                  "tasks": arrivedJob.tasks
                  // "tasks": arrivedJob.tasks.running + "/" + arrivedJob.tasks.total
                }
                
                if(uiJob.state === "RUNNING") {
                  uiJob.uiCancelOpertaionText = "Cancel Job" 
                }

                if(arrivedJob["end-time"] === -1) {
                  uiJob.endTime = null;
                }
                this.flinkJobs.push(uiJob);
              });
          }
        }
      }
      else if(executingTaskData.flinkTaskType == FlinkTaskType.UploadJar) {
        if(executingTaskData.data.includes("file uploaded")) {
          this._isUploadingToFlink = false;
          this._isUploadedToFlink = true;
        }
      }
      else if(executingTaskData.flinkTaskType == FlinkTaskType.GetDeployedJarList)  {
        if(executingTaskData.data.includes("address")) {
            const jarFilesObjResponse = JSON.parse(executingTaskData.data);
            this.deployedFlinkJars = [];
            jarFilesObjResponse.files.forEach(x=> this.deployedFlinkJars.push(x.id));
          }
      }
      else if(executingTaskData.flinkTaskType == FlinkTaskType.RunJar) {
        if(executingTaskData.data.includes("jobid")) {
          const flinkJob = JSON.parse(executingTaskData.data);
          this.runningJobs.push(flinkJob.jobid); 
          }
        }
      }
  }

  msToTime(millis) {
    const hours = `0${new Date(millis).getHours() - 2}`.slice(-2);
    const minutes = `0${new Date(millis).getMinutes()}`.slice(-2);
    const seconds = `0${new Date(millis).getSeconds()}`.slice(-2);

    const time = `${hours}:${minutes}:${seconds}`
    return time;
  }

  private buildConnection = () => {
    // let fakeToken = this.authService.accessToken;

    this.hubConnection = new signalR.HubConnectionBuilder()
      // .withUrl(this.HUB_URL)
      
      //.withUrl(this.HUB_URL, { accessTokenFactory: () => fakeToken }) //use your api adress here and make sure you use right hub name.
      .withUrl(this.HUB_URL, { accessTokenFactory: () => this.authService.accessToken }) //use your api adress here and make sure you use right hub name.
      .build();
  };

  public startConnection = () => {

    let self = this;

    this.hubConnection
      .start()
      .then(() => {
        console.log("UI succeeded to connect to HUB");
        this.connectedToHubServer = true;
        self.registerUI();
      })
      .catch(err => {
        self.connectedToHubServer = false;
        console.log("Error while starting connection: " + err);
        //if you get error try to start connection again after 3 seconds.

        setTimeout(function() {
          self.startConnection();
          self.registerUI();
        }, 3000);
      });
  };

  public registerUI() {
    if (this.hubConnection.state == HubConnectionState.Connected) {
      this.hubConnection.invoke("RegisterUI")
        .then(() => {
          this.getWorkerConnectedDeployments();
        })
    }
  }

  getAllFlows() {
    return this.httpClient.get(this.urlFlowGetterApi)
    .pipe(
      tap((arrivedData:ODFlow[]) => {

        this.availableFlows = [];

        arrivedData.forEach( flow => {
           
            let uIExecutingFlow: UIExecutingFlow = {
              "ODFlow": flow,
              "UITasks": []
            }

            flow.Tasks.forEach( task => {
              let uIExecutingTask = {
                ODTask:task,
                ExecutingTaskStatus: null,
                StdOut: null
              }
              uIExecutingFlow.UITasks.push(uIExecutingTask);
            });

            this.availableFlows.push(uIExecutingFlow);
        });

        return this.availableFlows;
      }),
      catchError(this.handleError)
    );
  }

  startFlow(flow: UIExecutingFlow) {

    this.currentRunningFlow = flow;

    let flowPayload: FlowPayload = {
      "FlowId": flow.ODFlow.Id,
      "DeploymentId": this.selectedDeploymentId
    };

    this.hubConnection.invoke("StartFlow", flowPayload)
      .then(() => {
        console.log("UI Sent 'StartFlow' to hub");
      })


    //   flow.UITasks.forEach(task => {
    //     this.startTask(task.ODTask.Id);
    //  });
  }

  stopFlow(uIExecutingFlow: UIExecutingFlow) {

    let flowPayload: FlowPayload = {
      "FlowExecuterId": this.currentRunningFlow.ExecutingFlowStatus.flowExecuterId,
      "DeploymentId": this.selectedDeploymentId
    };

    this.hubConnection.invoke("StopFlow", flowPayload)//this.currentRunningFlow.ExecutingFlowStatus.flowExecuterId)
      .then(() => {
        console.log("StopFlow...");
      })
  }

  startTask(taskId: string) {

    let taskPayload: TaskPayload = {
      "TaskId": taskId,
      "DeploymentId": this.selectedDeploymentId
    };

    this.hubConnection.invoke("StartTask", taskPayload)
      .then(() => {
        console.log("UI Sent 'StartTask' to hub");
      })
  }

  stopTask(executingTaskId: string) {

    let taskPayload: TaskPayload = {
      "ExecuterId": executingTaskId,
      "DeploymentId": this.selectedDeploymentId
    };

    this.hubConnection.invoke("StopTask", taskPayload)
      .then(() => {
        console.log("StopTask...");
      })
  }

  startFlinkTask(flinkTaskPaylod: FlinkTaskPayload) {

    if(this.hubConnection.state == HubConnectionState.Connected) {
    
      flinkTaskPaylod.DeploymentId = this.selectedDeploymentId;

      if(flinkTaskPaylod.FlinkTaskType == FlinkTaskType.StopJob)
      {
        let i=5;
      }

      this.hubConnection.invoke("StartFlinkTask", flinkTaskPaylod)
        .then(() => {
          console.log("UI Sent 'StartFlinkTask' to hub");
        })
    }
  }
  
  stopFlinkTask(executingFlinkTaskId: string) {

    this.hubConnection.invoke("StopFlinkTask", executingFlinkTaskId)
      .then(() => {
        console.log("StopFlinkTask...");
      })
  }

  getODTasks() {

    let options = {
      headers: {Authorization: this.authService.idToken}
    };

    return this.httpClient.get(this.urlTaskGetterApi, options)
      .pipe(
        tap((arrivedData: ODTask[]) => {

          this.availableTasks = arrivedData;

          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  deleteODTask(task: ODTask) {

    return this.httpClient.post(this.urlTaskRemoverApi, task)
      .pipe(
        tap((res: boolean) => {
          return res;
        }),
        catchError(this.handleError)
      );
  }

  updateODTask(task: ODTask) {
    return this.httpClient.post(this.urlTaskUpdateAPI, task)
      .pipe(
        tap((res: any) => {
          this.sendRefreshTasks();
          return res;
        }),
        catchError(this.handleError)
      );
  }

  sendRefreshTasks() {
     this.hubConnection.invoke("RefreshTasks")
      .then(() => {
        console.log("RefreshTasks...");
      })
  }

  addODTask(newTask: ODTask) {
    if (newTask.ODProgram != null) {
      newTask.CategoryGroup = this.stringOfEnum(CategoryGroup, newTask.ODProgram.CategoryGroup);
    }

    // newTask.FinalizationTaskName = "FinalizationTaskName";
    // newTask.FinalizationTaskId = "FinalizationTaskId";

    return this.httpClient.post(this.urlTaskInserterAPI, newTask)
      .pipe(
        tap((res: ODTask) => {

          return res;
        }),
        catchError(this.handleError)
      );
  }

  public getODPrograms() {
    
    let options = {
      headers: {Authorization: this.authService.idToken}
    };

    return this.httpClient.get(this.urlProgramGetterApi, options)
      .pipe(
        tap((arrivedData: ODProgram[]) => {

          this.odPrograms = arrivedData;

          return arrivedData;
        }),
        catchError(this.handleError)
      );

    //  this.httpClient.get<ODProgram[]>(this.urlProgramGetterApi).subscribe(data => {
    //     this.dataChange.next(data);
    //   },
    //   (error: HttpErrorResponse) => {
    //     console.log (error.name + ' ' + error.message);
    //   });   
  }

  public getWorkerConnectedDeployments() {
    if (this.hubConnection == null)
      return;

    if (this.hubConnection.state == HubConnectionState.Connected) {

      this.hubConnection.invoke("GetWorkerConnectedDeployments")
      .then(() => {
          console.log("UI Sent 'GetWorkerConnectedDeployments' to hub");
       })
    }
  }
  public getOPDockers() {

    if (this.hubConnection == null)
      return;

    if (this.hubConnection.state == HubConnectionState.Connected) {
      this.hubConnection.invoke("GetOperationalDockerList", this.selectedDeploymentId)
        .then(() => {
          console.log("UI Sent 'GetOperationalDockerList' to hub");
        })
    }
  }

  public getActiveDeployments() {
    return this.httpClient.get(this.urlDeploymentGettrApi)
      .pipe(
        tap((arrivedData: Deployment[]) => {

          this.activeDeployments = arrivedData;

          //TODO select the first as a default
          if(this.activeDeployments != null) {
            this.selectedDeploymentId = arrivedData[0].deployment_id;
          }

          // let tempDeployment: Deployment = {
          //   deployment_id: 'a01fdcontr26j7q'
          // }
          // this.activeDeployments.push(tempDeployment);

          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  public getConfigurations() {

    let payload = {
      "DeploymentId": this.selectedDeploymentId,
      "DeploymentRegion": 'us-east-1'
    }

    return this.httpClient.post(this.urlDeploymentGettrApi, payload)
      .pipe(
        tap((arrivedData: any[]) => {

          this.configurations = arrivedData;

          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  public getFlinkJars() {

     //"https://artifactory.il.alm-sg.com/artifactory/libs-release-local/intelsports/flinkflow/")

     return this.httpClient.get(this.urlFlinkJarGetterApi)
      .pipe(
        tap((arrivedData: string[]) => {

          this.availableJars = arrivedData;

          return this.availableJars;
        }),
        catchError(this.handleError)
      );
  
    // return this.httpClient.get("https://artifactory.il.alm-sg.com/artifactory/libs-release-local/intelsports/flinkflow/")
    //    .pipe(
    //     tap((arrivedData) => {

    //       this.flinkJars = arrivedData;
    //       return arrivedData;
    //     }),
    //     catchError(this.handleError)
    //   );
  }

  public getConfigContent(fileKey: string) {

    let payload = {
          "DeploymentId": this.selectedDeploymentId,
          "DeploymentRegion": 'us-east-1',
          "keyName": fileKey
        }

    return this.httpClient.post(this.urlConfigGetterAPI, payload)
      .pipe(
        tap((arrivedData: any) => {

          this.currentConfigContent = JSON.stringify(arrivedData);

          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  stringOfEnum(myEnum, enumValue) {
    for (var k in myEnum) {
      if (myEnum[k] == enumValue) {
        return k;
      }
    }
    return null;
  }

  signup() {
     return Auth.signUp("gilshalev2003@yahoo.com", "3456ertydfgh()G");
  }
  
  public mySignUp(email, password): Observable<any> {
    return fromPromise(Auth.signUp(email, password));
  }

  handleError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (!(error instanceof Response)) {
      errMsg = error.message ? error.message : error.toString();
    } else {
      const body = error.json() || '';
      const err = body || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    }
    console.error(errMsg);
    return Observable.throw(errMsg);
  }

  // addProgramToDynamoDB(newProgram: ODProgram) {

  //   let fakePrerequisite = [];
  //   fakePrerequisite.push(Prerequisite.DotNet);

  //   let odp = {
  //     "Name" : newProgram.Name,
  //     "Description": newProgram.Description,
  //     "Package":newProgram.Package,
  //     "IsPackageCompressed": newProgram.IsPackageCompressed,
  //     "ExecutedProgram":newProgram.ExecutedProgram,
  //     "ExecutedProgramParams":newProgram.ExecutedProgramParams,
  //     "CategoryGroup": newProgram.CategoryGroup,
  //     "ProgramType": newProgram.ProgramType,
  //     "Prerequisites": fakePrerequisite,
  //     "ConfigurationFile": newProgram.ConfigurationFile,
  //   }     

  //   return this.httpClient.post(this.urlProgramInserterAPI, odp)
  //     .pipe(
  //       tap((res:ODProgram) => {

  //         return res;
  //       }),
  //       catchError(this.handleError)
  //     );
  // }
}

 // get data(): ODProgram[] {
  //   return this.dataChange.value;
  // }

  // getDialogData() {
  //   return this.dialogData;
  // }




 // showProgress(message) {
  //      console.log (message);
  // }

//   private getEventMessage(event: HttpEvent<any>, file: File) {
//     switch (event.type) {
//       case HttpEventType.Sent:
//          return `Uploading file "${file.name}" of size ${file.size}.`;

//       case HttpEventType.UploadProgress:
//         // Compute and show the % done:
//         const percentDone = Math.round(100 * event.loaded / event.total);
//         return `File "${file.name}" is ${percentDone}% uploaded.`;

//         case HttpEventType.Response:
//           return `File "${file.name}" was completely uploaded!`;

//         default:
//           return `File "${file.name}" surprising upload event: ${event.type}.`;
//    }
// }














//  private convertEnumToString (statusOption: StatusOptions):string {
//       switch(statusOption) {
//         case StatusOptions.TaskStarting: {
//           reuturn "TaskStarting";
//         }
//        case StatusOptions.TaskStarted: {
//           reuturn "TaskStarted";
//         }
//         case StatusOptions.TaskCompleted: {
//           reuturn "TaskCompleted";
//         }
//         case StatusOptions.ProcessExited: {
//           reuturn "ProcessExited";
//         }
//         case StatusOptions.ErrorDataReceived: {
//           reuturn "ErrorDataReceived";
//         }
//         case StatusOptions.TaskStopped: {
//           reuturn "TaskStopped";
//         }
//         case StatusOptions.TaskStoppedError: {
//           reuturn "TaskStoppedError";
//         }
//       }
//   }


      //  const index = this.activeTasks.indexOf(foundActiveTask);
      //     if (index > -1) {
      //       this.activeTasks.splice(index, 1);
      //     }
      //    this.completedTasks.push(foundActiveTask);

       // if(foundActiveTask !=null) {
      //    foundActiveTask.ExecutingTaskStatus = executingTaskStatus;
      //    this.completedTasks.push(foundActiveTask);
      // }



   // getProgramPresignedUrl(programName: string, programPackage: string, categoryGroup: string) {
  //   let payload = {
  //     "ProgramName": programName,
  //     "Package":programPackage,
  //     "CategoryGroup": categoryGroup,
  //   }

  //    return this.httpClient.post(this.urlProgramGetUrlAPI, payload)
  //     .pipe(
  //       tap((url:string) => {
  //         return url;
  //       }),
  //       catchError(this.handleError)
  //     );
  // }

  // uploadFileToS3(url :string, file): boolean{

  //   //  const req = new HttpRequest('POST', url, file, {
  //   //     reportProgress: true
  //   //  });

  //   //  this.httpClient.request(req).pipe(
  //   //     map(event => this.getEventMessage(event, file)),
  //   //     tap(message => this.showProgress(message)),
  //   //     // last(), // return last (completed) message to caller
  //   //     // catchError(this.handleError(file))
  //   //   ).subscribe(data => {
  //   //     let i= data;
  //   //     return true
  //   //   },
  //   //   (error: HttpErrorResponse) => {
  //   //     console.log (error.name + ' ' + error.message);
  //   //     return false;
  //   //   });

  //   //  return false;

  //     var xhr = new XMLHttpRequest();

  //     xhr.open('PUT', url, false);

  //     xhr.setRequestHeader('Content-Type', 'application/octet-stream');

  //     xhr.onload = (ddd) => {
  //        if (xhr.status === 200) {
  //          console.log(ddd);
  //        }
  //     };

  //     xhr.onerror = (errorEvent) => {
  //        console.log(errorEvent);
  //     };

  //     xhr.onprogress = function (event) {
  //           console.log("event.loaded" + event.loaded);
  //           console.log("event.total" + event.total);
  //     };

  //     // var formData = new FormData();
  //     // formData.append("thefile", file);
  //     // xhr.send(formData);

  //     xhr.send(file);

  //     return true;
  // }

  // getFilteredFlows() {
    
  //   let firstUser = this.authService.userGroups[0];
    
  //   var ug = JSON.stringify(firstUser);

  //   let httpHeaders = new HttpHeaders({
  //     'Content-Type' : 'application/x-www-form-urlencoded'
  //   });    
   
  //   let options = {
  //     	headers: httpHeaders
  //    };    

  //   return this.httpClient.post(this.urlFlowGetterApi,ug,options)
  //   .pipe(
  //     tap((arrivedData:ODFlow[]) => {

  //       this.availableFlows = [];

  //       arrivedData.forEach( flow => {
           
  //           let uIExecutingFlow: UIExecutingFlow = {
  //             "ODFlow": flow,
  //             "UITasks": []
  //           }

  //           flow.Tasks.forEach( task => {
  //             let uIExecutingTask = {
  //               ODTask:task,
  //               ExecutingTaskStatus: null,
  //               StdOut: null
  //             }
  //             uIExecutingFlow.UITasks.push(uIExecutingTask);
  //           });

  //           this.availableFlows.push(uIExecutingFlow);
  //       });

  //       return this.availableFlows;
  //     }),
  //     catchError(this.handleError)
  //   );
  // }