import { webSocket } from 'rxjs/webSocket';
import {Injectable} from "@angular/core";
import {catchError, tap} from "rxjs/operators";
import {Observable} from "rxjs";
import {HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class MyWebSocketService {

  subject = webSocket('ws://localhost:4444/');

  urlTatsApi: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/taskmanager';//https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/Dev';

  constructor(private httpClient: HttpClient) { }

  loadTaskList() {
    return this.httpClient.get(this.urlTatsApi)
      .pipe(
        tap(res => {
          return res;
        }),
        catchError(this.handleError)
      );
  }

  handleError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (!(error instanceof Response)) {
      errMsg = error.message ? error.message : error.toString();
    } else {
      const body = error.json() || '';
      const err = body || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    }
    console.error(errMsg);
    return Observable.throw(errMsg);
  }
}

//IMPORTANT LINKS:
//https://docs.aws.amazon.com/AmazonS3/latest/dev/WebsiteAccessPermissionsReqd.html
//https://docs.aws.amazon.com/apigateway/latest/developerguide/how-to-cors.html


//https://docs.aws.amazon.com/AmazonS3/latest/dev/RESTAuthentication.html
// loadGames() {
//
//   //https://github.com/SamVerschueren/ngx-api-gateway-client
//   // var apigClient = apiGatewayClientFactory.newClient({
//   //   invokeUrl:'https://dev.deployment.fd19.sports.intel.com/fd19/games',
//   //   region: 'us-east-1',
//   //   accessKey : 'AKIAJAOGGOPNYW7WJUUQ',
//   //   secretKey: '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'
//   // });
//   //
//   // apigClient.invokeApi(undefined, undefined, 'GET', undefined, undefined)
//   //   .then(function(result){
//   //     //This is where you would put a success callback
//   //   }).catch( function(result){
//   //   //This is where you would put an error callback
//   // });
//
//   // apigClient.invokeApi(pathParams, pathTemplate, method, additionalParams, body)
//   //   .then(function(result){
//   //     //This is where you would put a success callback
//   //   }).catch( function(result){
//   //   //This is where you would put an error callback
//   // });
//
//   //   var apigClient = apigClientFactory.newClient({
//   //     invokeUrl:'https://xxxxx.execute-api.us-east-1.amazonaws.com', // REQUIRED
//   //
//   //     region: 'eu-west-1',                                           // REQUIRED: The region where the API is deployed.
//   //
//   //     accessKey: 'ACCESS_KEY',                                       // REQUIRED
//   //
//   //     secretKey: 'SECRET_KEY',                                       // REQUIRED
//   //
//   //     sessionToken: 'SESSION_TOKEN',                                 // OPTIONAL: If you are using temporary credentials
//   //     you must include the session token.
//   //
//   //       systemClockOffset: 0,                                          // OPTIONAL: An offset value in milliseconds to apply to signing time
//   //
//   //     retries: 4,                                                    // OPTIONAL: Number of times to retry before failing. Uses axios-retry plugin.
//   //
//   //     retryCondition: (err) => {                                     // OPTIONAL: Callback to further control if request should be retried.
//   //     return err.response && err.response.status === 500;          //           Uses axios-retry plugin.
//   //   },
//   //
//   //     retryDelay: 100 || 'exponential' || (retryCount, error) => {   // OPTIONAL: Define delay (in ms) as a number, a callback, or
//   //     return retryCount * 100                                      //           'exponential' to use the in-built exponential backoff
//   //   }                                                              //           function. Uses axios-retry plugin. Default is no delay.
//   // });
//   let options = {
//     params:
//       {
//         region: 'us-east-1',
//         accessKey : 'AKIAJAOGGOPNYW7WJUUQ',
//         secretKey: 'geXxF54HqfcHrkAviXy7QRIleu145gxhd5W/9xai'
//       }
//   }
//
//   //Signature = URL-Encode( Base64( HMAC-SHA1( YourSecretAccessKey, UTF-8-Encoding-Of( StringToSign ) ) ) );
//   return this.httpClient.get(this.urlGames+'?AWSAccessKeyId=AKIAJAOGGOPNYW7WJUUQ&Signature=', options)
//     .pipe(
//       tap(res => {
//         //this.eventsArr = res;
//         return res;
//       }),
//       catchError(this.handleError)
//     );
// }

// sendToServer(msg: String) {
//   //this.subject._subscribe();
//   this.subject.next(msg);
//   this.subject.complete();
// }

//
// loadEvents() {
//
//   return this.httpClient.get(this.urlEvents)
//     .pipe(
//       tap(res => {
//         //this.eventsArr = res;
//         return res;
//       }),
//       catchError(this.handleError)
//     );
// }
//
// loadDeployments() {
//
//   const httpOptions = {
//     headers: new HttpHeaders({
//       'Content-Type':  'application/json',
//       // 'Authorization': 'AWS Signature',
//       'AWSAccessKeyId': 'AKIAJAOGGOPNYW7WJUUQ',
//       'AWSSecretAccessKey': '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'
//       //'AWS Region': 'us-east-1'
//     })
//   };
//
//   return this.httpClient.get(this.urlDeployments, httpOptions)
//     .pipe(
//       tap(res => {
//         //this.eventsArr = res;
//         return res;
//       }),
//       catchError(this.handleError)
//     );
// }


//urlGames : string = 'https://dev.deployment.fd19.sports.intel.com/fd19/games';
//urlEvents :string = 'https://data-staging.platform.sports.intel.com/v1/nfl19/events';
//urlDeployments : string = 'https://dev.deployment.fd19.sports.intel.com/fd19/deployments';
