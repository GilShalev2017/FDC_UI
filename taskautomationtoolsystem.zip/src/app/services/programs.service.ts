import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable} from 'rxjs';
import {catchError, tap} from 'rxjs/operators';
import {ODProgram, CategoryGroup, ProgramType} from '../models/ODProgram';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import { AuthService } from './../auth/auth.service';

@Injectable()
export class ProgramsService {
 
  private urlProgramGetterApi: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/program-manager';
  private urlProgramInserterAPI: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/program-inserter';
  private urlProgramGetUrlAPI: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/program-uploader';
  private urlProgramRemoverApi: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/program-remover';
  private urlProgramUpdaterApi: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/program-updater';

  dataChange: BehaviorSubject<ODProgram[]> = new BehaviorSubject<ODProgram[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;

  constructor (private httpClient: HttpClient, private authService: AuthService) {}

  get data(): ODProgram[] {
    return this.dataChange.value;
  }

  getDialogData() {
    return this.dialogData;
  }

  getAllPrograms(): void {

    let options = {
      headers: {Authorization: this.authService.idToken}
    };

    this.httpClient.get<ODProgram[]>(this.urlProgramGetterApi, options).subscribe(data => {
   
         let dataCopy: ODProgram[]=  data;
         dataCopy.forEach((item) => {
            item.ProgramTypeString = this.stringOfEnum(ProgramType,item.ProgramType);
            item.CategoryGroupString = this.stringOfEnum(CategoryGroup,item.CategoryGroup);
         });

        this.dataChange.next(dataCopy);//data);
      },
      (error: HttpErrorResponse) => {
        console.log (error.name + ' ' + error.message);
      });
  }

  stringOfEnum(myEnum,enumValue) 
  {
    for (var k in myEnum) {
      if (myEnum[k] == enumValue) { 
        return k;
      }
    }
    return null;
  }
  
  addProgram (oDProgram: ODProgram): void {
    this.dialogData = oDProgram;
  }

  updateProgram (oDProgram: ODProgram): void {
    this.updateODProgram(oDProgram)
     .subscribe( (res) => {
        if(res === true) {
          this.dialogData = oDProgram;
        }
     });
  }
 
  updateODProgram(program: ODProgram) {
    
    return this.httpClient.post(this.urlProgramUpdaterApi, program)
      .pipe(
        tap((res:ODProgram) => {
          return res;
        }),
        catchError(this.handleError)
      );
  }

  deleteODProgram (oDProgram: ODProgram) {
  
    return this.httpClient.post(this.urlProgramRemoverApi,oDProgram)
      .pipe(
        tap((res:boolean) => {
          return res;
        }),
        catchError(this.handleError)
      );
  }

  getProgramPresignedUrl(programName: string, programPackage: string, categoryGroup: string) {
    let payload = {
      "ProgramName": programName,
      "Package":programPackage,
      "CategoryGroup": categoryGroup,
    }
    
     return this.httpClient.post(this.urlProgramGetUrlAPI, payload)
      .pipe(
        tap((url:string) => {
          return url;
        }),
        catchError(this.handleError)
      );
  }

  uploadFileToS3(url :string, file): boolean{

    //  const req = new HttpRequest('POST', url, file, {
    //     reportProgress: true
    //  });

    //  this.httpClient.request(req).pipe(
    //     map(event => this.getEventMessage(event, file)),
    //     tap(message => this.showProgress(message)),
    //     // last(), // return last (completed) message to caller
    //     // catchError(this.handleError(file))
    //   ).subscribe(data => {
    //     let i= data;
    //     return true
    //   },
    //   (error: HttpErrorResponse) => {
    //     console.log (error.name + ' ' + error.message);
    //     return false;
    //   });

    //  return false;

      var xhr = new XMLHttpRequest();

      xhr.open('PUT', url, false);

      xhr.setRequestHeader('Content-Type', 'application/octet-stream');

      xhr.onload = (event) => {

         var prog = Math.round(event.loaded * 100 / event.total); 
         console.log("prog=" + prog);
         if (xhr.status === 200) {
           console.log(event);
         }
      };
      
      xhr.onerror = (errorEvent) => {
         console.log(errorEvent);
      };

      xhr.onprogress = function (event) {
            var prog = Math.round(event.loaded * 100 / event.total); 
            console.log("prog=" + prog);
            console.log("event.loaded" + event.loaded);
            console.log("event.total" + event.total);
      };

      // var formData = new FormData();
      // formData.append("thefile", file);
      // xhr.send(formData);

      xhr.send(file);

      return true;
  }

  addProgramToDynamoDB(newProgram: ODProgram) {
  
    let odp = {
      "Name" : newProgram.Name,
      "Description": newProgram.Description,
      "Package":newProgram.Package,
      "IsPackageCompressed": newProgram.IsPackageCompressed,
      "ExecutedProgram": "temp",
      "ExecutedProgramParams":newProgram.ExecutedProgramParams,
      "CategoryGroup": newProgram.CategoryGroup,
      "ProgramType": newProgram.ProgramType,
      "ConfigurationFile": newProgram.ConfigurationFile,
    }     
    
    //var progTypeInt: number = parseInt(newProgram.ProgramType.toString(), 10);
    let progTypeString = newProgram.ProgramType.toString();
    // let programTypeString = this.stringOfEnum(ProgramType,newProgram.ProgramType);

    // let progType:ProgramType = ProgramType[programTypeString];

    if(progTypeString == 'dotnet') {
      odp.ExecutedProgram = "dotnet";
    }
    else if(progTypeString == 'java') {
      odp.ExecutedProgram = "java";
    }
    else if(progTypeString == 'python') {
      odp.ExecutedProgram = "python";
    }
    else if(progTypeString == 'bashScript') {
      odp.ExecutedProgram = "/bin/bash";
    }
    else if(progTypeString == 'golang') {
      odp.ExecutedProgram = "golang";
    }
    else if(progTypeString == 'windowsBatchScript') {
      odp.ExecutedProgram = "C:\\Windows\\System32\\cmd.exe";
      odp.ExecutedProgramParams = "/C " + odp.ExecutedProgramParams;
    }
    else if(progTypeString == 'none') {
      odp.ExecutedProgram = "";
    }

    return this.httpClient.post(this.urlProgramInserterAPI, odp)
      .pipe(
        tap((res:ODProgram) => {

          return res;
        }),
        catchError(this.handleError)
      );
  }

  handleError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (!(error instanceof Response)) {
      errMsg = error.message ? error.message : error.toString();
    } else {
      const body = error.json() || '';
      const err = body || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    }
    console.error(errMsg);
    return Observable.throw(errMsg);
  }
}



/* REAL LIFE CRUD Methods I've used in my projects. ToasterService uses Material Toasts for displaying messages:

    // ADD, POST METHOD
    addItem(kanbanItem: KanbanItem): void {
    this.httpClient.post(this.API_URL, kanbanItem).subscribe(data => {
      this.dialogData = kanbanItem;
      this.toasterService.showToaster('Successfully added', 3000);
      },
      (err: HttpErrorResponse) => {
      this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
    });
   }

    // UPDATE, PUT METHOD
     updateItem(kanbanItem: KanbanItem): void {
    this.httpClient.put(this.API_URL + kanbanItem.id, kanbanItem).subscribe(data => {
        this.dialogData = kanbanItem;
        this.toasterService.showToaster('Successfully edited', 3000);
      },
      (err: HttpErrorResponse) => {
        this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }

  // DELETE METHOD
  deleteItem(id: number): void {
    this.httpClient.delete(this.API_URL + id).subscribe(data => {
      console.log(data['']);
        this.toasterService.showToaster('Successfully deleted', 3000);
      },
      (err: HttpErrorResponse) => {
        this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }
*/




 // getExecutedProgram(newProgram: ODProgram): string {
  //     switch (newProgram.ProgramType) {
  //       case ProgramType.dotnet:
  //         return "dotnet"; 
  //         break;
  //       case ProgramType.java:
  //         return "java"; 
  //         break;
  //       case ProgramType.python:
  //         return "python";  
  //         break;
  //       case ProgramType.bashScript:
  //         return "/bin/bash"; 
  //         break;
  //       case ProgramType.golang:
  //         return "golang"; 
  //         break;
  //    }
  // }