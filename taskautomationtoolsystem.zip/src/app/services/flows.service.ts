import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable} from 'rxjs';
import {catchError, tap} from 'rxjs/operators';
import {ODFlow} from '../models/ODFlow';
import {UIExecutingFlow} from '../models/UIExecutingFlow';
import {UIExecutingTask} from '../models/UIExecutingTask';
import {ODTask} from '../models/ODTask';
import {HttpClient, HttpErrorResponse, HttpHeaders} from '@angular/common/http';
import {OperationsService} from "../services/operations.service";
import { AuthService } from './../auth/auth.service';

@Injectable()
export class FlowsService {
 
  private urlFlowGetterApi: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/flows-manager';
  private urlFlowInserterAPI: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/flows-inserter';
  // private urlFlowGetUrlAPI: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/flows-uploader';
  private urlFlowRemoverApi: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/flows-remover';
  private urlFlowUpdaterApi: string = 'https://nceb9q4dbi.execute-api.eu-west-1.amazonaws.com/TST/flows-updater';

  dataChange: BehaviorSubject<ODFlow[]> = new BehaviorSubject<ODFlow[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;
  public availableFlows: UIExecutingFlow[];

  constructor (private httpClient: HttpClient,
               private authService: AuthService,
               private operationsService: OperationsService) {}

  get data(): ODFlow[] {
    return this.dataChange.value;
  }

  getDialogData() {
    return this.dialogData;
  }

  getAllFlows() {
     
    //   let firstUser = this.authService.userGroups[0];
    //   var ug = JSON.stringify(firstUser);
    //   let httpHeaders = new HttpHeaders({
    //    'Content-Type' : 'application/x-www-form-urlencoded'
    //    });    
    //   let options = {
    //    	headers: httpHeaders
    //    };    

    // return this.httpClient.post(this.urlFlowGetterApi,ug,options)
  
    return this.httpClient.get(this.urlFlowGetterApi)
      .pipe(
        tap((arrivedData:ODFlow[]) => {

          this.availableFlows = [];

          arrivedData.forEach( flow => {
             
              let uIExecutingFlow: UIExecutingFlow = {
                "ODFlow": flow,
                "UITasks": []
              }

              flow.Tasks.forEach( task => {
                let uIExecutingTask = {
                  ODTask:task,
                  ExecutingTaskStatus: null,
                  StdOut: null
                }
                uIExecutingFlow.UITasks.push(uIExecutingTask);
              });

              this.availableFlows.push(uIExecutingFlow);
          });

          return this.availableFlows;
        }),
        catchError(this.handleError)
      );
  }

  stringOfEnum(myEnum,enumValue) 
  {
    for (var k in myEnum) {
      if (myEnum[k] == enumValue) { 
        return k;
      }
    }
    return null;
  }
  
  addFlow (oDFlow: ODFlow): void {
    this.dialogData = oDFlow;
  }

  updateFlow (oDFlow: ODFlow): void {
    this.updateODFlow(oDFlow)
     .subscribe( (res) => {
        if(res === true) {
          this.dialogData = oDFlow;
        }
     });
  }
 
  updateODFlow(flow: ODFlow) {
    
    return this.httpClient.post(this.urlFlowUpdaterApi, flow)
      .pipe(
        tap((res:ODFlow) => {
          return res;
        }),
        catchError(this.handleError)
      );
  }

  deleteODFlow (uiExecutingFlow: UIExecutingFlow) {
  
    return this.httpClient.post(this.urlFlowRemoverApi,uiExecutingFlow.ODFlow)
      .pipe(
        tap((res:boolean) => {
          return res;
        }),
        catchError(this.handleError)
      );
   }

   addFlowToDynamoDB(newFlow: ODFlow) {
  
    // let odf = {
    //   "Name" : newFlow.Name,
    //   "Description": newFlow.Description,
    //   // "CreatedBy":newFlow.CreatedBy,
    //   // "CreatedAt": newFlow.CreatedAt,
    //   "Tasks": []
    //   // newFlow.Tasks
    // }     

    return this.httpClient.post(this.urlFlowInserterAPI, newFlow)
      .pipe(
        tap((res:ODFlow) => {

          return res;
        }),
        catchError(this.handleError)
      );
  }

  handleError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (!(error instanceof Response)) {
      errMsg = error.message ? error.message : error.toString();
    } else {
      const body = error.json() || '';
      const err = body || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    }
    console.error(errMsg);
    return Observable.throw(errMsg);
  }
}



/* REAL LIFE CRUD Methods I've used in my projects. ToasterService uses Material Toasts for displaying messages:

    // ADD, POST METHOD
    addItem(kanbanItem: KanbanItem): void {
    this.httpClient.post(this.API_URL, kanbanItem).subscribe(data => {
      this.dialogData = kanbanItem;
      this.toasterService.showToaster('Successfully added', 3000);
      },
      (err: HttpErrorResponse) => {
      this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
    });
   }

    // UPDATE, PUT METHOD
     updateItem(kanbanItem: KanbanItem): void {
    this.httpClient.put(this.API_URL + kanbanItem.id, kanbanItem).subscribe(data => {
        this.dialogData = kanbanItem;
        this.toasterService.showToaster('Successfully edited', 3000);
      },
      (err: HttpErrorResponse) => {
        this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }

  // DELETE METHOD
  deleteItem(id: number): void {
    this.httpClient.delete(this.API_URL + id).subscribe(data => {
      console.log(data['']);
        this.toasterService.showToaster('Successfully deleted', 3000);
      },
      (err: HttpErrorResponse) => {
        this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }
*/




 // getAllFlows(): void {
  //   this.httpClient.get<ODFlow[]>(this.urlFlowGetterApi).subscribe(data => {
   
  //        let flows: ODFlow[]=  data;

  //        flows.forEach( flow => {
         
  //           let tasksString = "";
            
  //           flow.Tasks.forEach( task => {
  //             tasksString = tasksString + ", " + task.Name;
  //           });

  //           flow.TasksString = tasksString;
         
  //        });
         
  //       //  dataCopy.forEach((item) => {
  //       //     item.ProgramTypeString = this.stringOfEnum(ProgramType,item.ProgramType);
  //       //     item.CategoryGroupString = this.stringOfEnum(CategoryGroup,item.CategoryGroup);
  //       //  });
  //       this.flows = flows;

  //       this.dataChange.next(flows);

  //       return
  //     },
  //     (error: HttpErrorResponse) => {
  //       console.log (error.name + ' ' + error.message);
  //     });
  // }