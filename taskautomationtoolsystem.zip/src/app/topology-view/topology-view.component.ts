import { Component, OnInit } from '@angular/core';
import {OperationsService} from "../services/operations.service";

@Component({
  selector: 'app-topology-view',
  templateUrl: './topology-view.component.html',
  styleUrls: ['./topology-view.component.css']
})
export class TopologyViewComponent implements OnInit {

  constructor(public operationsService: OperationsService) { }

  ngOnInit() {
    this.operationsService.getOPDockers();
  }

  // addProduct() {
  //   this.operationsService.availableOPDockers.push({ Id: Math.random().toString(36).substring(7), Name: Math.random().toString(36).substring(50), picture: { url: 'https://dummyimage.com/600x400/000/fff' } })
  // }

}
