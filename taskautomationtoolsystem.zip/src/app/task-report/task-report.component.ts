import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-report',
  templateUrl: './task-report.component.html',
  styleUrls: ['./task-report.component.css']
})
export class TaskReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
