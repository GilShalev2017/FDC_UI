import { Component, OnInit } from '@angular/core';
// import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

const MODALS = {
  focusFirst: "",
  autofocus: ""
};

@Component({
  selector: 'app-confirmation-dialog',
  templateUrl: './confirmation-dialog.component.html',
  styleUrls: ['./confirmation-dialog.component.css']
})
export class ConfirmationDialogComponent implements OnInit {

  withAutofocus = `<button type="button" ngbAutofocus class="btn btn-danger"
      (click)="modal.close('Ok click')">Ok</button>`;

  // open(name: string) {
  //   this._modalService.open(MODALS[name]);
  // }

  // constructor(private _modalService: NgbModal) { }

  ngOnInit() {
  }

}
