import { Component, OnInit, ViewChild } from '@angular/core';
import { OperationsService } from "../services/operations.service";
import { AuthService } from './../auth/auth.service';
import { JsonEditorComponent, JsonEditorOptions } from 'ang-jsoneditor';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-configurations',
  templateUrl: './configurations.component.html',
  styleUrls: ['./configurations.component.css']
})
export class ConfigurationsComponent implements OnInit {

  public editorOptions: JsonEditorOptions;
  public dataFake: any;
  @ViewChild(JsonEditorComponent, { static: false }) editor: JsonEditorComponent;
 
  // public form: FormGroup;

  constructor(public operationsService: OperationsService,
              public auth: AuthService) { 
                
    this.editorOptions = new JsonEditorOptions()
    this.editorOptions.modes = ['code', 'text', 'tree', 'view'];//, 'expandAll']; // set all allowed modes
    //this.options.mode = 'code'; //set only one mode

    this.dataFake = {"products":[{"name":"car","product":[{"name":"honda","model":[{"id":"civic","name":"civic"},{"id":"accord","name":"accord"},{"id":"crv","name":"crv"},{"id":"pilot","name":"pilot"},{"id":"odyssey","name":"odyssey"}]}]}]}

   
  }

  ngOnInit() {
    // this.operationsService.getConfigurations()
    // .subscribe();

    //this.initForm();
  }

  // initForm() {
  //    this.form = this.fb.group({
  //     myinput: [this.data]
  //   });
  // }

  refresh() {
    // this.operationsService.getConfigurations()
    // .subscribe();
  }

  onConfigFileSelected(event: any) {
    this.operationsService.getConfigContent(event)
      .subscribe();
  }

  getData(event) {

  }
}
