import {Component, Inject, OnInit, AfterViewInit, TemplateRef, ViewChild, ElementRef } from '@angular/core';
import {ODTask} from "../models/ODTask";
import {ODProgram} from "../models/ODProgram";
import {UIExecutingTask} from "../models/UIExecutingTask";
import {MatDialog} from '@angular/material/dialog';
import {faCoffee, faEdit, faFileArchive, faStop, faPlay,faCalendar, faRecycle, faEye} from '@fortawesome/free-solid-svg-icons';
import {TaskDefinitionComponent} from "../task-definition/task-definition.component";
import {BsModalService, BsModalRef} from 'ngx-bootstrap/modal';
import {ConfirmationDialogComponent} from "../confirmation-dialog/confirmation-dialog.component";
import {ToastrService} from 'ngx-toastr';
import {OperationsService} from "../services/operations.service";
import {animate, state, style, transition, trigger} from '@angular/animations';
import {HubConnectionState} from "@aspnet/signalr/dist/esm/HubConnection";

@Component({
  selector: 'app-task-view',
  templateUrl: './task-view.component.html',
  styleUrls: ['./task-view.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class TaskViewComponent implements OnInit  {

  isCardView: boolean = false;
  toView:string = "To Card View";

  newODTask : ODTask;
  editedODTask: ODTask;
  modalRef: BsModalRef;

  faEdit = faEdit;
  faFileArchive = faFileArchive;
  faStop = faStop;
  faPlay = faPlay;
  faCalendar = faCalendar;
  faRecycle = faRecycle;
  faEye = faEye;

  connectToServer = "Connect to Server !!!";
  
  confirmMessage: string;
 
  // colors = [{ status: "TaskStarting", color: "black" }, { status: "TaskStarted", color: "black" }, 
  //           { status: "TaskCompleted", color: "black" }, { status: "ProcessExited", color: "black" },
  //           { status: "ErrorDataReceived", color: "red" }, { status: "TaskStopped", color: "black" },
  //           { status: "TaskStoppedError", color: "red" }, { status: "TaskCompletedWithError", color: "red" }];

  constructor(public operationsService: OperationsService,
              private modalService: BsModalService,
              public dialog: MatDialog ,
              private toastr: ToastrService) {
  }

  // getTheColor(status) {
  //   return this.colors.filter(item => item.status === status)[0].color 
  //       // could be better written, but you get the idea
  // }

  openConfirmDeleteModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, {class: 'modal-sm'});
  }
 
  confirmRegister(): void {
    this.operationsService.registerUI();
    this.modalRef.hide();
  }
 
  declineRegister(): void {
    this.modalRef.hide();
  }

  ngOnInit() {
    this.getAvailableTasks();
    this.getAvailablePrograms();
  }

  reloadData() {
     this.getAvailableTasks();
  }

  openSaveNewTaskModal(templateNewTask: TemplateRef<any>) {
    this.newODTask = new ODTask();
    this.newODTask.ODProgram = new ODProgram();

    // this.newODTask.FinalizationTask = new ODTask();
    // this.newODTask.FinalizationTaskName = "FinalizationTaskName";
    // this.newODTask.FinalizationTaskId = "FinalizationTaskId";

    this.newODTask.ReportStandardOutput = true;
    this.modalRef = this.modalService.show(templateNewTask);
  }

  openEditTaskModal(templateEditTask: TemplateRef<any>, task: ODTask) {
    this.editedODTask = {
      "Id": task.Id,
      "ODProgramId": task.ODProgramId,
      "Name": task.Name,
      "CategoryGroup": task.CategoryGroup,
      "Description": task.Description,
      "ODProgramName": task.ODProgramName,
      "TaskParameters": task.TaskParameters,
      
      // "FinalizationTaskId": task.FinalizationTaskId,
      // "FinalizationTaskName": task.FinalizationTaskName,
      //"FinalizationTaskId": task.FinalizationTaskId,
      // "WorkingDirectory": task.WorkingDirectory,
      "ReportStandardOutput": task.ReportStandardOutput
    };
    this.modalRef = this.modalService.show(templateEditTask);
  }

  deleteTask(task :ODTask)   {

    if (confirm('Are you sure you want to delete this task?')) {
      this.operationsService.deleteODTask(task)
        .subscribe( (res: boolean) => {
          this.getAvailableTasks();
        });
    } else {
      // Do nothing!
    }
  }

  getAvailableTasks() {
    this.operationsService.getODTasks()
      .subscribe( (arrivedData: ODTask[]) => {
      });
  }
  
  getAvailablePrograms() {
    if(this.operationsService.odPrograms.length == 0) {
        this.operationsService.getODPrograms()
         .subscribe( (odps: ODProgram[]) => {
        });
      }
  }

  addNewODTask(template) {
    this.newODTask = new ODTask();
    this.newODTask.Name = "";
    // this.newODTask.FinalizationTask = new ODTask();
    // this.newODTask.FinalizationTask.Name = "";

    this.modalRef = this.modalService.show(template);
  }

  updateODTask(task: ODTask) {
    this.operationsService.updateODTask(task).subscribe(
      (data: any) => {
        this.getAvailableTasks();
      });
  }

  saveNewODTask(task: ODTask) {

    task.ODProgramId = task.ODProgram.Id;
    task.ODProgramName = task.ODProgram.Name;

    this.operationsService.addODTask(task).subscribe(
      (data: ODTask) => {
        this.getAvailableTasks();
      });
 }

  dupliacteODTask(task: ODTask) {
    this.operationsService.addODTask(task).subscribe(
      (data: ODTask) => {
        this.getAvailableTasks();
      });
  }
 
  runTask(task : ODTask, template: TemplateRef<any>) {
 
    if(this.operationsService.registeredToHubServer == false) {
        this.modalRef = this.modalService.show(template, {class: 'modal-sm'});
    }
    else
    {
      this.operationsService.startTask(task.Id);
    }
  }

  stopTask(task: UIExecutingTask, event?: Event){
      if (event) {
        event.stopPropagation();
      } 
      this.operationsService.stopTask(task.ExecutingTaskStatus.executerId);
  }

  registerUI() {
    this.operationsService.registerUI();
  }

  cleanHistory() {
    this.operationsService.activeTasks = [];
  }

  toggleView() {
    
    this.isCardView = !this.isCardView;

    if(this.isCardView == true) {
      this.toView = "To Table View";
    }
    else {
      this.toView = "To Card View";
    }
  }
}


 // this.toastr.warning('Are you sure you want to delete?', 'Delete Warning', {
    //   timeOut: 3000
    // });
    // this.toastr.success('Are you sure you want to delete?', 'Delete Warning', {
    //   timeOut: 3000
    // });
    // this.toastr.info('Are you sure you want to delete?', 'Delete Warning', {
    //   timeOut: 3000
    // });
    // this.toastr.error('Are you sure you want to delete?', 'Delete Warning', {
    //   timeOut: 3000
    // });
    // this.toastr.info('message <button type="button" class="btn clear btn-toastr" onclick="toastr.clear()">OK</button>' , 'Studio Message 444:');
    // this.toastr.info(`Are you sure?<button>Yes</button>`, 'Studio Message:');
    // this.openDialog();

  //    openStreamingLog(tatsTask: TatsTask)  {
  //   this.signalRService.displayStreamingLog();
  // }

  // openDialog() {
  //   const dialogRef = this.dialog.open(ConfirmationDialogComponent);

  //   dialogRef.afterClosed().subscribe(result => {
  //     console.log(`Dialog result: ${result}`);
  //   });
  // }

  
  // ngAfterViewInit() {
  //   let id = this.operationsService.logLines.length;
  //   const itemToScrollTo = document.getElementById('item-' + id);
  //   // null check to ensure that the element actually exists
  //   if (itemToScrollTo) {
  //     itemToScrollTo.scrollIntoView(true);
  //   }
  // }

 