import {ODTask} from "./ODTask";

export class ODFlow {
  Id?: string;
  Name?: string;
  Description?: string;
  CreatedBy?: string;
  CreatedAt?: string;
  Tasks?: ODTask[];
  TasksString?: string;
  IsFinished?: boolean;
  DurationInMillis?: number;
  RunInParallel?: string;
 }