export class ExecutingFlowStatus {
  flowId: string;
  flowExecuterId?: string;
  operationalDockerId?: string;
  deploymentId?: string;
  startDateTime?: string;
  endDateTime?: string; 
  Status?: FlowStatusOptions; 
  StatusString?: string; 
  errorData? : string;
}

export enum FlowStatusOptions {
  FlowStarting,
  FlowStarted,
  FlowCompleted,
  FlowCompletedWithError,
  FlowStopped,
  FlowStoppedError,
}