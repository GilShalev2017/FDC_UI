import {FlinkTaskType} from "./FlinkTaskPayload";

export class ExecutingTaskData {
  taskId: string;
  executerId?: string;
  operationalDocker?: string;
  deploymentId?: string;
  data?: string;
  flowExecuterId? : string;
  flowId?: string;
  isFlinkTask?: boolean;
  flinkTaskType?: FlinkTaskType
}