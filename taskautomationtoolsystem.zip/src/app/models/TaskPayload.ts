export class TaskPayload {
    TaskId?: string;
    DeploymentId?: string;
    ExecuterId?: string;
}