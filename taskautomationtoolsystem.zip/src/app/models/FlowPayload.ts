export class FlowPayload {
    FlowId?: string;
    DeploymentId?: string;
    FlowExecuterId?: string;
}