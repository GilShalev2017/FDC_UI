import {ODFlow} from "./ODFlow";
import {UIExecutingTask} from "./UIExecutingTask";
import {ExecutingFlowStatus} from "./ExecutingFlowStatus";

export class UIExecutingFlow
{
  ODFlow: ODFlow; //from DB

  ExecutingFlowStatus?: ExecutingFlowStatus; //from HUB
  
  UITasks?: UIExecutingTask[];
}