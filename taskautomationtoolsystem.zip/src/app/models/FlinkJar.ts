export class FlinkJar {
  Name?: string;
  Path?: string;
}