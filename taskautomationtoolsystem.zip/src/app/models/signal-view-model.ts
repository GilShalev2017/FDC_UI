export class SignalViewModel {
  customerName: string;
  description: string;
  area: string;
  zone: string;
  signalStamp: string;
}
