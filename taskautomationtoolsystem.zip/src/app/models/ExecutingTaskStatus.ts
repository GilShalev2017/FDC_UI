export class ExecutingTaskStatus {
  taskId: string;
  executerId?: string;
  operationalDocker?: string;
  deploymentId?: string;
  startDateTime?: string;
  endDateTime?: string;
  statusOptions?: StatusOptions; 
  statusString?: string; 
  errorData?:string; 
  flowExecuterId? : string;
}

export enum StatusOptions {
  TaskStarting,
  TaskStarted,
  TaskCompleted,
  TaskCompletedWithError,
  ProcessExited,
  ErrorDataReceived,
  TaskStopped,
  TaskStoppedError,
}