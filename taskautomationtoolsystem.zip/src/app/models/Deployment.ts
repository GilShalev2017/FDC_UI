export class Deployment {
    deployment_status?: string;
    deployment_name?: string;
    deployment_id?: string;
}