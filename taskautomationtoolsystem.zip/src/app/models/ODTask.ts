import {ODProgram} from "./ODProgram";

export class ODTask {
  Id: string;
  
  ODProgramId?: string;
  ODProgramName?: string;
  ODProgram?: ODProgram;
  
  CategoryGroup?: string;
  Name: string;
  Description?: string;
  ProgramToExecute?: string;
  ProgramParameters?: string;
  TaskParameters?: string;
  ReportStandardOutput?: boolean;

  
  // FinalizationTaskId?: string;
  // FinalizationTaskName?: string;
  // FinalizationTask?: ODTask;
  // WorkingDirectory?: string;
}
