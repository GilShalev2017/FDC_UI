export class OperationalDocker {
  name: string;
  connectionId?: string;
  connectionStatus?: string;
  groupName?: string;
  deploymentId?: string;
}