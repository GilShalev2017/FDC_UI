import {ODTask} from "./ODTask";
import {ExecutingTaskStatus} from "./ExecutingTaskStatus";

export class UIExecutingTask
{
  ODTask: ODTask; //from DB

  ExecutingTaskStatus?: ExecutingTaskStatus; //from HUB

  StdOut?: string[]; //from Worker
  expanded? : boolean; //UI  
}