export class ODProgram {
  Id?: string;
  Name?: string;
  Description?: string;
  Package?: string;
  IsPackageCompressed?: boolean;
  ExecutedProgram?: string;
  ExecutedProgramParams?: string;
  CategoryGroup?: CategoryGroup;
  CategoryGroupString?: string;
  ProgramType?: ProgramType;
  ProgramTypeString?: string;
//   Prerequisites?: Prerequisite[];
  ConfigurationFile?: string;
//   state: string;
 }

export enum ProgramType {
    dotnet,
    java,
    python,
    bashScript,
    golang,
    windowsBatchScript,
    none,
}

export enum CategoryGroup {
    DeploymentConfiguration,
    Validation,
    Publishers,
    Playback,
    Flink,
    None
}

// export enum Prerequisite {
//     AwsCredentials,
//     AwsCli,
//     Kubectl,
//     Java,
//     DotNet,
//     Zip,
//     None,
// }