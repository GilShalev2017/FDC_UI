import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ODFlow} from "../models/ODFlow";
import { ODTask} from "../models/ODTask";
import { AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import { FlowsService} from "../services/flows.service";

import {SelectionModel} from '@angular/cdk/collections';
import {CdkDragDrop, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-add-flow',
  templateUrl: './add-flow.component.html',
  styleUrls: ['./add-flow.component.css']
})
export class AddFlowComponent implements OnInit {

   
  @Output() flowSaved: EventEmitter<ODFlow> = new EventEmitter<ODFlow>();

  selectedTasks:ODTask[] = [];

  nameDescriptionFormGroup: FormGroup;
  tasksFormGroup: FormGroup;
  runInParallel : string = "false";
  
  constructor(private _formBuilder: FormBuilder,
              private flowsService: FlowsService) { }
  
  ngOnInit() {

    this.nameDescriptionFormGroup = this._formBuilder.group({
      nameCtrl: ['', Validators.required],
      descriptionCtrl: ['', Validators.required]
    });
    this.tasksFormGroup = this._formBuilder.group({
      
    });

  }

  saveFlow() {
    
      let group = this.nameDescriptionFormGroup.value;
      let name = group["nameCtrl"];
      let description = group["descriptionCtrl"];

      let newFlow:ODFlow = {};
      newFlow.Name = name;
      newFlow.Description = description;
      newFlow.Tasks = this.selectedTasks;
      newFlow.RunInParallel = this.runInParallel;

      this.flowsService.addFlowToDynamoDB(newFlow)
       .subscribe( elm => {
            this.flowSaved.emit(newFlow);
            this.flowsService.getAllFlows();
      });
  }
  
  onRunModeChange(value: string) {
    if(value =="1") {
      this.runInParallel = "true";
    }
    else {
      this.runInParallel = "false";
    }
  }

  drop(event: CdkDragDrop<string[]>) {

    moveItemInArray(this.selectedTasks, event.previousIndex, event.currentIndex);
  }
}
