import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { AuthService } from './auth/auth.service';
import {OperationsService} from "./services/operations.service";

import { TemplateRef } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'operation-client-app';
  subscription: Subscription;
  public loggedIn: boolean;
  clientHeight: number;
  
  connectedUsrEmail: string;

  modalRef: BsModalRef;

  constructor(public operationsService: OperationsService,  public auth: AuthService, private modalService: BsModalService) {

    this.clientHeight = window.innerHeight; 
  }

  ngOnInit() {

    // this.operationsService.getOPDockers();
    this.operationsService.getActiveDeployments()
     .subscribe();

    this.subscription = this.auth.isAuthenticated()
      .subscribe(result => {
        this.loggedIn = result;
      });

    this.subscription = this.auth.getCurrentAuthenticatedUser()
      .subscribe(result => {
        this.connectedUsrEmail = result.attributes.email;
      });

    window.setTimeout(() => {
       this.init();
    }, 2000);
   
     this.auth.loggedIn.subscribe(data => {
      //do what ever needs doing when data changes
      this.loggedIn = data;
     });
  }

  init() {
    this.operationsService.hubConnectionInit();

    this.operationsService.getWorkerConnectedDeployments();
    this.operationsService.getOPDockers();
  }

  onOff() {
   
    // this.operationsService.startConnection();
    this.operationsService.registerUI();
   
    // this.operationsService.connectedToSignalServer = !(this.operationsService.connectedToSignalServer);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  onClickLogout() {
    this.auth.signOut();
    this.connectedUsrEmail = "";
    this.loggedIn = false;
  }

  onSelectDeploymentChange() {
    this.operationsService.getOPDockers();
    this.operationsService.flinkJobs = [];
    this.operationsService.deploymentSelectionChanged.next(true);
  }

   openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

}
